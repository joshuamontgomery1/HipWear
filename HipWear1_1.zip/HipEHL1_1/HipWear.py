# Code created by Dr Joshua Montgomery (Univeristy of Essex, 2026)

import sys
import numpy as np
import pandas as pd
import HipWear
import time
import os
import matplotlib.pyplot as plt

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QDialog, QDoubleSpinBox, QHBoxLayout,
    QLabel, QLayout, QPushButton, QSizePolicy,
    QSpacerItem, QSpinBox, QTabWidget, QVBoxLayout,
    QWidget)
from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure

class Ui_Dialog(object):

    def run_model(self):

        try:

            # Read GUI inputs
            nt1 = self.nt1.value()
            nt2 = self.nt2.value()

            omigp_in = self.OMIGP.value()
            omiex_in = self.OMIEX.value()
            omiey_in = self.OMIEY.value()
            omiez_in = self.OMIEZ.value()

            facx_in = self.FACX.value()
            facy_in = self.FACY.value()
            facz_in = self.FACZ.value()    

            errp_con_in = self.ERRP_con.value()
            erwx_con_in = self.ERWX_con.value()
            erwy_con_in = self.ERWY_com.value()
            erwz_con_in = self.ERWZ_con.value()

            errc_in = self.ERRC.value()

            n_w_circle_in = self.n_W_circle.value()

            cr12_in = self.CR12.value()*1e-6
            r0_in = self.R0.value()*1e-3
            e0_in = self.E0.value()*1e6

            alpha_in = self.alpha.value()*1e-15

            n_updt_intv_in = int(self.n_updt_intv.value())
            n_updt = self.n_updt.value()

            icase_in = self.ICASE.value()
            n_gts_in = self.n_gts.value()

            print("\n ICASE="+str(self.ICASE.value()) +"\n")

            start_time = time.time()
            # Run HipWear
            pmax, hmin, pmax_array = HipWear.wear_wrapper.wear_run(
                nt1,
                nt2,
                omigp_in,
                omiex_in,
                omiey_in,
                omiez_in,
                facx_in,
                facy_in,
                facz_in,
                errp_con_in,
                erwx_con_in,
                erwy_con_in,
                erwz_con_in,
                errc_in,
                n_w_circle_in,
                cr12_in,
                r0_in,
                e0_in,
                alpha_in,
                n_updt_intv_in,
                n_updt,
                icase_in,
                n_gts_in
            )
            elapsed_time=(time.time() - start_time)
            print("--- %s seconds ---" % elapsed_time)
 

            # Display outputs
            self.plot_figures()

            self.Output1.setText(
                f"Maximum Pressure (MPa) = {pmax:.3f}"
            )

            self.Output2.setText(
                f"Minimum Film (um) = {hmin:.2e}"
            )

            self.Output3.setText(
                f"Pmax Array Length = {len(pmax_array)}"
            )

            self.Output2_3.setText(
                f"Execution Time (s) = {elapsed_time:.3f}"
            )

            print("HipWear completed successfully")

        except Exception as e:

            print("HipWear error:")
            print(e)

            self.Output1.setText("ERROR")
            self.Output2.setText(str(e))
            self.Output3.setText("")
            self.Output2_3.setText("") 

    def initialise_plots(self):
        self.figures = []
        self.canvases = []

        plot_widgets = [
            self.widget,
            self.widget_2,
            self.widget_3,
            self.widget_4,
            self.widget_5,
            self.widget_6
        ]

        for plot_widget in plot_widgets:

            fig = Figure(constrained_layout=True)
            canvas = FigureCanvas(fig)

            layout = QVBoxLayout(plot_widget)
            #layout.setContentsMargins(0, 0, 0, 0)
            layout.addWidget(canvas)

            canvas.setMinimumSize(0, 0)

            canvas.setSizePolicy(
                QSizePolicy.Ignored,
                QSizePolicy.Ignored
                )

            self.figures.append(fig)
            self.canvases.append(canvas)

    def plot_figures(self):
            r0_in = self.R0.value()*1e-3

            for fig in self.figures:
                fig.clear()
            #Figures
            pwd = os.getcwd()
            #file_wd=pwd+"\\2nd cycle\\"
            file_wd=pwd+"\\"

            #Figure 1
            ax = self.figures[0].add_subplot(111)
            wc_a = pd.read_fwf(file_wd+"wc_a.dat",header=None)
            Z = wc_a.to_numpy()
            x = np.linspace(0, 180, wc_a.shape[1])
            y = np.linspace(0, 180, wc_a.shape[0])
            X, Y = np.meshgrid(x, y)

            contour=ax.contourf(X, Y, Z, levels=50, cmap="viridis")
            cbar=plt.colorbar(contour,ax=ax)
            ax.set_title("Wear Without Creep")
            cbar.set_label('Wear (m)')
            ax.set_xlabel("Degrees")
            ax.set_ylabel("Degrees")
            #plt.show()

            #Figure 2
            ax = self.figures[3].add_subplot(111)
            wv = pd.read_fwf(file_wd+"wv.dat",header=None)
            ax.plot(wv)
            ax.set_ylabel("Volumetric Wear ($m^3$)")
            ax.set_xlabel("Wear Cycles (million)")
            ax.set_title("Volumetric Wear Against Time")
            
            #Figure 3
            ax = self.figures[1].add_subplot(111)
            wv_cp = pd.read_fwf(file_wd+"wv_cp.dat",header=None)
            ax.plot(wv_cp)
            ax.set_ylabel("Creep (m)")
            ax.set_xlabel("Wear Cycles (million)")
            ax.set_title("Creep of Acetebular Cup")

            #Figure 4
            ax = self.figures[4].add_subplot(111)
            hmcpmax = pd.read_fwf(file_wd+"hmcpmax.dat",header=None)
            ax.plot(hmcpmax.iloc[:,4])
            ax.set_ylabel("Pressure (MPa)")
            ax.set_xlabel("Cycle Timestep")
            ax.set_title("Maximum Pressure Across 1 Cycle")         

            #Figure 5
            ax = self.figures[2].add_subplot(111)
            hmcpmax = pd.read_fwf(file_wd+"hmcpmax.dat",header=None)
            ax.plot(hmcpmax.iloc[:,1])
            ax.set_ylabel("Min Film ($\mu$m)")
            ax.set_xlabel("Cycle Timestep")
            ax.set_title("Minimum Film Across 1 Cycle")

            #Figure 6
            time_s=self.time_step.value()
            ax = self.figures[5].add_subplot(111)
            p_entr = pd.read_fwf(file_wd+"p_entr.dat",header=None)
            p_side = pd.read_fwf(file_wd+"p_side.dat",header=None)

            p_entr = pd.read_fwf(file_wd+"p_entr.dat",header=None)
            x=np.linspace(-r0_in,r0_in,p_entr.iloc[:,time_s].size)
            ax.plot(x,p_entr.iloc[:,time_s])

            ax.set_ylabel("Pressure (MPa)")
            ax.set_xlabel("X Position (m)")
            ax.set_title("Cross Section of Pressure at timestep: "+str(time_s))

            # Force redraw
            for canvas in self.canvases:
                canvas.draw()
            QApplication.processEvents()    
    
    def setupUi(self, Dialog):
        if not Dialog.objectName():
            Dialog.setObjectName(u"Dialog")
        Dialog.resize(995, 612)
        self.verticalLayout_22 = QVBoxLayout(Dialog)
        self.verticalLayout_22.setObjectName(u"verticalLayout_22")
        self.tabWidget = QTabWidget(Dialog)
        self.tabWidget.setObjectName(u"tabWidget")
        self.inputs = QWidget()
        self.inputs.setObjectName(u"inputs")
        self.horizontalLayout_23 = QHBoxLayout(self.inputs)
        self.horizontalLayout_23.setObjectName(u"horizontalLayout_23")
        self.verticalLayout_7 = QVBoxLayout()
        self.verticalLayout_7.setObjectName(u"verticalLayout_7")
        self.verticalLayout_19 = QVBoxLayout()
        self.verticalLayout_19.setObjectName(u"verticalLayout_19")
        self.label_17 = QLabel(self.inputs)
        self.label_17.setObjectName(u"label_17")
        font = QFont()
        font.setPointSize(13)
        font.setBold(True)
        font.setUnderline(True)
        self.label_17.setFont(font)
        self.label_17.setWordWrap(True)

        self.verticalLayout_19.addWidget(self.label_17)

        self.label_36 = QLabel(self.inputs)
        self.label_36.setObjectName(u"label_36")
        font1 = QFont()
        font1.setPointSize(9)
        font1.setBold(False)
        font1.setItalic(True)
        font1.setUnderline(False)
        self.label_36.setFont(font1)
        self.label_36.setWordWrap(True)

        self.verticalLayout_19.addWidget(self.label_36)


        self.verticalLayout_7.addLayout(self.verticalLayout_19)

        self.verticalLayout_5 = QVBoxLayout()
        self.verticalLayout_5.setObjectName(u"verticalLayout_5")
        self.label_28 = QLabel(self.inputs)
        self.label_28.setObjectName(u"label_28")
        font2 = QFont()
        font2.setPointSize(12)
        font2.setBold(True)
        self.label_28.setFont(font2)
        self.label_28.setAlignment(Qt.AlignCenter)

        self.verticalLayout_5.addWidget(self.label_28)

        self.horizontalLayout_10 = QHBoxLayout()
        self.horizontalLayout_10.setObjectName(u"horizontalLayout_10")
        self.label_15 = QLabel(self.inputs)
        self.label_15.setObjectName(u"label_15")
        self.label_15.setAlignment(Qt.AlignCenter)

        self.horizontalLayout_10.addWidget(self.label_15)

        self.nt1 = QSpinBox(self.inputs)
        self.nt1.setObjectName(u"nt1")
        self.nt1.setMinimum(1)
        self.nt1.setMaximum(200)

        self.horizontalLayout_10.addWidget(self.nt1)


        self.verticalLayout_5.addLayout(self.horizontalLayout_10)

        self.horizontalLayout_11 = QHBoxLayout()
        self.horizontalLayout_11.setObjectName(u"horizontalLayout_11")
        self.label_16 = QLabel(self.inputs)
        self.label_16.setObjectName(u"label_16")
        self.label_16.setAlignment(Qt.AlignCenter)

        self.horizontalLayout_11.addWidget(self.label_16)

        self.nt2 = QSpinBox(self.inputs)
        self.nt2.setObjectName(u"nt2")
        self.nt2.setMinimum(1)
        self.nt2.setMaximum(200)

        self.horizontalLayout_11.addWidget(self.nt2)


        self.verticalLayout_5.addLayout(self.horizontalLayout_11)

        self.horizontalLayout_24 = QHBoxLayout()
        self.horizontalLayout_24.setObjectName(u"horizontalLayout_24")
        self.label_37 = QLabel(self.inputs)
        self.label_37.setObjectName(u"label_37")
        self.label_37.setAlignment(Qt.AlignCenter)

        self.horizontalLayout_24.addWidget(self.label_37)

        self.n_gts = QSpinBox(self.inputs)
        self.n_gts.setObjectName(u"n_gts")
        self.n_gts.setMinimum(1)
        self.n_gts.setMaximum(200)
        self.n_gts.setValue(50)

        self.horizontalLayout_24.addWidget(self.n_gts)


        self.verticalLayout_5.addLayout(self.horizontalLayout_24)

        self.horizontalLayout_15 = QHBoxLayout()
        self.horizontalLayout_15.setObjectName(u"horizontalLayout_15")
        self.label_21 = QLabel(self.inputs)
        self.label_21.setObjectName(u"label_21")
        self.label_21.setAlignment(Qt.AlignCenter)

        self.horizontalLayout_15.addWidget(self.label_21)

        self.ICASE = QSpinBox(self.inputs)
        self.ICASE.setObjectName(u"ICASE")
        self.ICASE.setMinimum(0)
        self.ICASE.setMaximum(2)
        self.ICASE.setValue(2)

        self.horizontalLayout_15.addWidget(self.ICASE)


        self.verticalLayout_5.addLayout(self.horizontalLayout_15)


        self.verticalLayout_7.addLayout(self.verticalLayout_5)

        self.verticalLayout = QVBoxLayout()
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.label_26 = QLabel(self.inputs)
        self.label_26.setObjectName(u"label_26")
        self.label_26.setFont(font2)
        self.label_26.setAlignment(Qt.AlignCenter)

        self.verticalLayout.addWidget(self.label_26)

        self.horizontalLayout = QHBoxLayout()
        self.horizontalLayout.setObjectName(u"horizontalLayout")
        self.label = QLabel(self.inputs)
        self.label.setObjectName(u"label")
        self.label.setAlignment(Qt.AlignCenter)

        self.horizontalLayout.addWidget(self.label)

        self.OMIGP = QDoubleSpinBox(self.inputs)
        self.OMIGP.setObjectName(u"OMIGP")
        self.OMIGP.setMaximum(1.000000000000000)
        self.OMIGP.setSingleStep(0.100000000000000)
        self.OMIGP.setValue(0.200000000000000)

        self.horizontalLayout.addWidget(self.OMIGP)


        self.verticalLayout.addLayout(self.horizontalLayout)

        self.horizontalLayout_2 = QHBoxLayout()
        self.horizontalLayout_2.setObjectName(u"horizontalLayout_2")
        self.label_2 = QLabel(self.inputs)
        self.label_2.setObjectName(u"label_2")
        self.label_2.setAlignment(Qt.AlignCenter)

        self.horizontalLayout_2.addWidget(self.label_2)

        self.OMIEX = QDoubleSpinBox(self.inputs)
        self.OMIEX.setObjectName(u"OMIEX")
        self.OMIEX.setMaximum(1.000000000000000)
        self.OMIEX.setSingleStep(0.100000000000000)
        self.OMIEX.setValue(1.000000000000000)

        self.horizontalLayout_2.addWidget(self.OMIEX)


        self.verticalLayout.addLayout(self.horizontalLayout_2)

        self.horizontalLayout_3 = QHBoxLayout()
        self.horizontalLayout_3.setObjectName(u"horizontalLayout_3")
        self.label_3 = QLabel(self.inputs)
        self.label_3.setObjectName(u"label_3")
        self.label_3.setAlignment(Qt.AlignCenter)

        self.horizontalLayout_3.addWidget(self.label_3)

        self.OMIEY = QDoubleSpinBox(self.inputs)
        self.OMIEY.setObjectName(u"OMIEY")
        self.OMIEY.setMaximum(1.000000000000000)
        self.OMIEY.setSingleStep(0.100000000000000)
        self.OMIEY.setValue(1.000000000000000)

        self.horizontalLayout_3.addWidget(self.OMIEY)


        self.verticalLayout.addLayout(self.horizontalLayout_3)

        self.horizontalLayout_4 = QHBoxLayout()
        self.horizontalLayout_4.setObjectName(u"horizontalLayout_4")
        self.label_4 = QLabel(self.inputs)
        self.label_4.setObjectName(u"label_4")
        self.label_4.setAlignment(Qt.AlignCenter)

        self.horizontalLayout_4.addWidget(self.label_4)

        self.OMIEZ = QDoubleSpinBox(self.inputs)
        self.OMIEZ.setObjectName(u"OMIEZ")
        self.OMIEZ.setMaximum(1.000000000000000)
        self.OMIEZ.setSingleStep(0.100000000000000)
        self.OMIEZ.setValue(1.000000000000000)

        self.horizontalLayout_4.addWidget(self.OMIEZ)


        self.verticalLayout.addLayout(self.horizontalLayout_4)


        self.verticalLayout_7.addLayout(self.verticalLayout)

        self.verticalSpacer = QSpacerItem(20, 40, QSizePolicy.Minimum, QSizePolicy.Expanding)

        self.verticalLayout_7.addItem(self.verticalSpacer)


        self.horizontalLayout_23.addLayout(self.verticalLayout_7)

        self.verticalLayout_9 = QVBoxLayout()
        self.verticalLayout_9.setObjectName(u"verticalLayout_9")
        self.verticalLayout_3 = QVBoxLayout()
        self.verticalLayout_3.setObjectName(u"verticalLayout_3")
        self.label_40 = QLabel(self.inputs)
        self.label_40.setObjectName(u"label_40")
        self.label_40.setFont(font2)
        self.label_40.setAlignment(Qt.AlignCenter)

        self.verticalLayout_3.addWidget(self.label_40)

        self.horizontalLayout_6 = QHBoxLayout()
        self.horizontalLayout_6.setObjectName(u"horizontalLayout_6")
        self.label_6 = QLabel(self.inputs)
        self.label_6.setObjectName(u"label_6")
        self.label_6.setAlignment(Qt.AlignCenter)

        self.horizontalLayout_6.addWidget(self.label_6)

        self.FACX = QDoubleSpinBox(self.inputs)
        self.FACX.setObjectName(u"FACX")
        self.FACX.setMaximum(200.000000000000000)
        self.FACX.setSingleStep(1.000000000000000)
        self.FACX.setValue(20.000000000000000)

        self.horizontalLayout_6.addWidget(self.FACX)


        self.verticalLayout_3.addLayout(self.horizontalLayout_6)

        self.horizontalLayout_7 = QHBoxLayout()
        self.horizontalLayout_7.setObjectName(u"horizontalLayout_7")
        self.label_7 = QLabel(self.inputs)
        self.label_7.setObjectName(u"label_7")
        self.label_7.setAlignment(Qt.AlignCenter)

        self.horizontalLayout_7.addWidget(self.label_7)

        self.FACY = QDoubleSpinBox(self.inputs)
        self.FACY.setObjectName(u"FACY")
        self.FACY.setMaximum(200.000000000000000)
        self.FACY.setSingleStep(1.000000000000000)
        self.FACY.setValue(20.000000000000000)

        self.horizontalLayout_7.addWidget(self.FACY)


        self.verticalLayout_3.addLayout(self.horizontalLayout_7)

        self.horizontalLayout_8 = QHBoxLayout()
        self.horizontalLayout_8.setObjectName(u"horizontalLayout_8")
        self.label_8 = QLabel(self.inputs)
        self.label_8.setObjectName(u"label_8")
        self.label_8.setAlignment(Qt.AlignCenter)

        self.horizontalLayout_8.addWidget(self.label_8)

        self.FACZ = QDoubleSpinBox(self.inputs)
        self.FACZ.setObjectName(u"FACZ")
        self.FACZ.setMaximum(200.000000000000000)
        self.FACZ.setSingleStep(1.000000000000000)
        self.FACZ.setValue(30.000000000000000)

        self.horizontalLayout_8.addWidget(self.FACZ)


        self.verticalLayout_3.addLayout(self.horizontalLayout_8)


        self.verticalLayout_9.addLayout(self.verticalLayout_3)

        self.verticalLayout_10 = QVBoxLayout()
        self.verticalLayout_10.setObjectName(u"verticalLayout_10")
        self.label_27 = QLabel(self.inputs)
        self.label_27.setObjectName(u"label_27")
        self.label_27.setFont(font2)
        self.label_27.setAlignment(Qt.AlignCenter)

        self.verticalLayout_10.addWidget(self.label_27)

        self.verticalLayout_8 = QVBoxLayout()
        self.verticalLayout_8.setObjectName(u"verticalLayout_8")
        self.horizontalLayout_12 = QHBoxLayout()
        self.horizontalLayout_12.setObjectName(u"horizontalLayout_12")
        self.label_22 = QLabel(self.inputs)
        self.label_22.setObjectName(u"label_22")
        self.label_22.setAlignment(Qt.AlignCenter)

        self.horizontalLayout_12.addWidget(self.label_22)

        self.ERRP_con = QDoubleSpinBox(self.inputs)
        self.ERRP_con.setObjectName(u"ERRP_con")
        self.ERRP_con.setMinimum(0.010000000000000)
        self.ERRP_con.setMaximum(0.100000000000000)
        self.ERRP_con.setSingleStep(0.010000000000000)
        self.ERRP_con.setValue(0.010000000000000)

        self.horizontalLayout_12.addWidget(self.ERRP_con)


        self.verticalLayout_8.addLayout(self.horizontalLayout_12)

        self.horizontalLayout_13 = QHBoxLayout()
        self.horizontalLayout_13.setObjectName(u"horizontalLayout_13")
        self.label_23 = QLabel(self.inputs)
        self.label_23.setObjectName(u"label_23")
        self.label_23.setAlignment(Qt.AlignCenter)

        self.horizontalLayout_13.addWidget(self.label_23)

        self.ERWX_con = QDoubleSpinBox(self.inputs)
        self.ERWX_con.setObjectName(u"ERWX_con")
        self.ERWX_con.setMinimum(0.010000000000000)
        self.ERWX_con.setMaximum(0.100000000000000)
        self.ERWX_con.setSingleStep(0.010000000000000)
        self.ERWX_con.setValue(0.050000000000000)

        self.horizontalLayout_13.addWidget(self.ERWX_con)


        self.verticalLayout_8.addLayout(self.horizontalLayout_13)

        self.horizontalLayout_16 = QHBoxLayout()
        self.horizontalLayout_16.setObjectName(u"horizontalLayout_16")
        self.label_24 = QLabel(self.inputs)
        self.label_24.setObjectName(u"label_24")
        self.label_24.setAlignment(Qt.AlignCenter)

        self.horizontalLayout_16.addWidget(self.label_24)

        self.ERWY_com = QDoubleSpinBox(self.inputs)
        self.ERWY_com.setObjectName(u"ERWY_com")
        self.ERWY_com.setMinimum(0.010000000000000)
        self.ERWY_com.setMaximum(0.100000000000000)
        self.ERWY_com.setSingleStep(0.010000000000000)
        self.ERWY_com.setValue(0.100000000000000)

        self.horizontalLayout_16.addWidget(self.ERWY_com)


        self.verticalLayout_8.addLayout(self.horizontalLayout_16)

        self.horizontalLayout_17 = QHBoxLayout()
        self.horizontalLayout_17.setObjectName(u"horizontalLayout_17")
        self.label_25 = QLabel(self.inputs)
        self.label_25.setObjectName(u"label_25")
        self.label_25.setAlignment(Qt.AlignCenter)

        self.horizontalLayout_17.addWidget(self.label_25)

        self.ERWZ_con = QDoubleSpinBox(self.inputs)
        self.ERWZ_con.setObjectName(u"ERWZ_con")
        self.ERWZ_con.setMinimum(0.010000000000000)
        self.ERWZ_con.setMaximum(0.100000000000000)
        self.ERWZ_con.setSingleStep(0.010000000000000)
        self.ERWZ_con.setValue(0.050000000000000)

        self.horizontalLayout_17.addWidget(self.ERWZ_con)


        self.verticalLayout_8.addLayout(self.horizontalLayout_17)


        self.verticalLayout_10.addLayout(self.verticalLayout_8)

        self.verticalLayout_4 = QVBoxLayout()
        self.verticalLayout_4.setObjectName(u"verticalLayout_4")
        self.horizontalLayout_9 = QHBoxLayout()
        self.horizontalLayout_9.setObjectName(u"horizontalLayout_9")
        self.label_13 = QLabel(self.inputs)
        self.label_13.setObjectName(u"label_13")
        self.label_13.setAlignment(Qt.AlignCenter)
        self.label_13.setWordWrap(True)

        self.horizontalLayout_9.addWidget(self.label_13)

        self.n_W_circle = QSpinBox(self.inputs)
        self.n_W_circle.setObjectName(u"n_W_circle")
        self.n_W_circle.setMinimum(50)
        self.n_W_circle.setMaximum(200)
        self.n_W_circle.setValue(100)

        self.horizontalLayout_9.addWidget(self.n_W_circle)


        self.verticalLayout_4.addLayout(self.horizontalLayout_9)


        self.verticalLayout_10.addLayout(self.verticalLayout_4)


        self.verticalLayout_9.addLayout(self.verticalLayout_10)

        self.verticalLayout_2 = QVBoxLayout()
        self.verticalLayout_2.setObjectName(u"verticalLayout_2")
        self.label_41 = QLabel(self.inputs)
        self.label_41.setObjectName(u"label_41")
        self.label_41.setFont(font2)
        self.label_41.setAlignment(Qt.AlignCenter)

        self.verticalLayout_2.addWidget(self.label_41)

        self.horizontalLayout_5 = QHBoxLayout()
        self.horizontalLayout_5.setObjectName(u"horizontalLayout_5")
        self.label_5 = QLabel(self.inputs)
        self.label_5.setObjectName(u"label_5")
        self.label_5.setAlignment(Qt.AlignCenter)

        self.horizontalLayout_5.addWidget(self.label_5)

        self.ERRC = QDoubleSpinBox(self.inputs)
        self.ERRC.setObjectName(u"ERRC")
        self.ERRC.setMaximum(1.000000000000000)
        self.ERRC.setSingleStep(0.100000000000000)
        self.ERRC.setValue(0.050000000000000)

        self.horizontalLayout_5.addWidget(self.ERRC)


        self.verticalLayout_2.addLayout(self.horizontalLayout_5)

        self.verticalSpacer_2 = QSpacerItem(20, 40, QSizePolicy.Minimum, QSizePolicy.Expanding)

        self.verticalLayout_2.addItem(self.verticalSpacer_2)


        self.verticalLayout_9.addLayout(self.verticalLayout_2)


        self.horizontalLayout_23.addLayout(self.verticalLayout_9)

        self.verticalLayout_11 = QVBoxLayout()
        self.verticalLayout_11.setObjectName(u"verticalLayout_11")
        self.verticalLayout_12 = QVBoxLayout()
        self.verticalLayout_12.setObjectName(u"verticalLayout_12")
        self.label_29 = QLabel(self.inputs)
        self.label_29.setObjectName(u"label_29")
        self.label_29.setFont(font2)
        self.label_29.setAlignment(Qt.AlignCenter)

        self.verticalLayout_12.addWidget(self.label_29)

        self.verticalLayout_13 = QVBoxLayout()
        self.verticalLayout_13.setObjectName(u"verticalLayout_13")
        self.horizontalLayout_18 = QHBoxLayout()
        self.horizontalLayout_18.setObjectName(u"horizontalLayout_18")
        self.label_31 = QLabel(self.inputs)
        self.label_31.setObjectName(u"label_31")
        self.label_31.setAlignment(Qt.AlignCenter)

        self.horizontalLayout_18.addWidget(self.label_31)

        self.E0 = QSpinBox(self.inputs)
        self.E0.setObjectName(u"E0")
        self.E0.setMinimum(100)
        self.E0.setMaximum(1000000)
        self.E0.setSingleStep(10)
        self.E0.setValue(660)

        self.horizontalLayout_18.addWidget(self.E0)


        self.verticalLayout_13.addLayout(self.horizontalLayout_18)

        self.horizontalLayout_19 = QHBoxLayout()
        self.horizontalLayout_19.setObjectName(u"horizontalLayout_19")
        self.label_32 = QLabel(self.inputs)
        self.label_32.setObjectName(u"label_32")
        self.label_32.setAlignment(Qt.AlignCenter)

        self.horizontalLayout_19.addWidget(self.label_32)

        self.R0 = QSpinBox(self.inputs)
        self.R0.setObjectName(u"R0")
        self.R0.setMinimum(14)
        self.R0.setMaximum(30)
        self.R0.setValue(16)

        self.horizontalLayout_19.addWidget(self.R0)


        self.verticalLayout_13.addLayout(self.horizontalLayout_19)

        self.horizontalLayout_20 = QHBoxLayout()
        self.horizontalLayout_20.setObjectName(u"horizontalLayout_20")
        self.label_33 = QLabel(self.inputs)
        self.label_33.setObjectName(u"label_33")
        self.label_33.setAlignment(Qt.AlignCenter)

        self.horizontalLayout_20.addWidget(self.label_33)

        self.CR12 = QDoubleSpinBox(self.inputs)
        self.CR12.setObjectName(u"CR12")
        self.CR12.setMinimum(1.000000000000000)
        self.CR12.setMaximum(1000.000000000000000)
        self.CR12.setSingleStep(0.010000000000000)
        self.CR12.setValue(50.000000000000000)

        self.horizontalLayout_20.addWidget(self.CR12)


        self.verticalLayout_13.addLayout(self.horizontalLayout_20)


        self.verticalLayout_12.addLayout(self.verticalLayout_13)


        self.verticalLayout_11.addLayout(self.verticalLayout_12)

        self.verticalLayout_16 = QVBoxLayout()
        self.verticalLayout_16.setObjectName(u"verticalLayout_16")
        self.label_35 = QLabel(self.inputs)
        self.label_35.setObjectName(u"label_35")
        self.label_35.setFont(font2)
        self.label_35.setAlignment(Qt.AlignCenter)

        self.verticalLayout_16.addWidget(self.label_35)

        self.verticalLayout_15 = QVBoxLayout()
        self.verticalLayout_15.setObjectName(u"verticalLayout_15")
        self.horizontalLayout_22 = QHBoxLayout()
        self.horizontalLayout_22.setObjectName(u"horizontalLayout_22")
        self.label_34 = QLabel(self.inputs)
        self.label_34.setObjectName(u"label_34")
        self.label_34.setAlignment(Qt.AlignCenter)

        self.horizontalLayout_22.addWidget(self.label_34)

        self.alpha = QDoubleSpinBox(self.inputs)
        self.alpha.setObjectName(u"alpha")
        self.alpha.setMaximum(1000.000000000000000)
        self.alpha.setSingleStep(0.010000000000000)
        self.alpha.setValue(0.100000000000000)

        self.horizontalLayout_22.addWidget(self.alpha)


        self.verticalLayout_15.addLayout(self.horizontalLayout_22)


        self.verticalLayout_16.addLayout(self.verticalLayout_15)

        self.verticalLayout_14 = QVBoxLayout()
        self.verticalLayout_14.setObjectName(u"verticalLayout_14")
        self.horizontalLayout_21 = QHBoxLayout()
        self.horizontalLayout_21.setObjectName(u"horizontalLayout_21")
        self.label_30 = QLabel(self.inputs)
        self.label_30.setObjectName(u"label_30")
        self.label_30.setAlignment(Qt.AlignCenter)
        self.label_30.setWordWrap(True)

        self.horizontalLayout_21.addWidget(self.label_30)

        self.n_updt_intv = QDoubleSpinBox(self.inputs)
        self.n_updt_intv.setObjectName(u"n_updt_intv")
        self.n_updt_intv.setValue(1.000000000000000)

        self.horizontalLayout_21.addWidget(self.n_updt_intv)


        self.verticalLayout_14.addLayout(self.horizontalLayout_21)


        self.verticalLayout_16.addLayout(self.verticalLayout_14)

        self.verticalLayout_6 = QVBoxLayout()
        self.verticalLayout_6.setObjectName(u"verticalLayout_6")
        self.horizontalLayout_14 = QHBoxLayout()
        self.horizontalLayout_14.setObjectName(u"horizontalLayout_14")
        self.label_20 = QLabel(self.inputs)
        self.label_20.setObjectName(u"label_20")
        self.label_20.setAlignment(Qt.AlignCenter)

        self.horizontalLayout_14.addWidget(self.label_20)

        self.n_updt = QSpinBox(self.inputs)
        self.n_updt.setObjectName(u"n_updt")
        self.n_updt.setMinimum(1)
        self.n_updt.setMaximum(200)

        self.horizontalLayout_14.addWidget(self.n_updt)


        self.verticalLayout_6.addLayout(self.horizontalLayout_14)

        self.verticalLayout_17 = QVBoxLayout()
        self.verticalLayout_17.setObjectName(u"verticalLayout_17")

        self.verticalLayout_6.addLayout(self.verticalLayout_17)


        self.verticalLayout_16.addLayout(self.verticalLayout_6)


        self.verticalLayout_11.addLayout(self.verticalLayout_16)

        self.pushButton = QPushButton(self.inputs)
        self.pushButton.setObjectName(u"pushButton")

        self.verticalLayout_11.addWidget(self.pushButton)

        self.verticalLayout_20 = QVBoxLayout()
        self.verticalLayout_20.setObjectName(u"verticalLayout_20")
        self.label_39 = QLabel(self.inputs)
        self.label_39.setObjectName(u"label_39")
        self.label_39.setFont(font2)
        self.label_39.setAlignment(Qt.AlignCenter)

        self.verticalLayout_20.addWidget(self.label_39)

        self.Output1 = QLabel(self.inputs)
        self.Output1.setObjectName(u"Output1")
        self.Output1.setAlignment(Qt.AlignCenter)

        self.verticalLayout_20.addWidget(self.Output1)

        self.Output2 = QLabel(self.inputs)
        self.Output2.setObjectName(u"Output2")
        self.Output2.setAlignment(Qt.AlignCenter)

        self.verticalLayout_20.addWidget(self.Output2)

        self.Output3 = QLabel(self.inputs)
        self.Output3.setObjectName(u"Output3")
        self.Output3.setAlignment(Qt.AlignCenter)

        self.verticalLayout_20.addWidget(self.Output3)

        self.Output2_3 = QLabel(self.inputs)
        self.Output2_3.setObjectName(u"Output2_3")
        self.Output2_3.setAlignment(Qt.AlignCenter)

        self.verticalLayout_20.addWidget(self.Output2_3)

        self.verticalSpacer_3 = QSpacerItem(20, 40, QSizePolicy.Minimum, QSizePolicy.Expanding)

        self.verticalLayout_20.addItem(self.verticalSpacer_3)


        self.verticalLayout_11.addLayout(self.verticalLayout_20)


        self.horizontalLayout_23.addLayout(self.verticalLayout_11)

        self.horizontalSpacer = QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.horizontalLayout_23.addItem(self.horizontalSpacer)

        self.tabWidget.addTab(self.inputs, "")
        self.Plots = QWidget()
        self.Plots.setObjectName(u"Plots")
        self.verticalLayout_18 = QVBoxLayout(self.Plots)
        self.verticalLayout_18.setObjectName(u"verticalLayout_18")
        self.horizontalLayout_31 = QHBoxLayout()
        self.horizontalLayout_31.setObjectName(u"horizontalLayout_31")
        self.verticalLayout_21 = QVBoxLayout()
        self.verticalLayout_21.setObjectName(u"verticalLayout_21")
        self.label_18 = QLabel(self.Plots)
        self.label_18.setObjectName(u"label_18")
        self.label_18.setFont(font)
        self.label_18.setWordWrap(True)

        self.verticalLayout_21.addWidget(self.label_18)

        self.label_38 = QLabel(self.Plots)
        self.label_38.setObjectName(u"label_38")
        self.label_38.setFont(font1)
        self.label_38.setWordWrap(True)

        self.verticalLayout_21.addWidget(self.label_38)


        self.horizontalLayout_31.addLayout(self.verticalLayout_21)

        self.horizontalLayout_28 = QHBoxLayout()
        self.horizontalLayout_28.setSpacing(6)
        self.horizontalLayout_28.setObjectName(u"horizontalLayout_28")
        self.horizontalLayout_28.setSizeConstraint(QLayout.SetMaximumSize)
        self.label_9 = QLabel(self.Plots)
        self.label_9.setObjectName(u"label_9")
        self.label_9.setMaximumSize(QSize(100, 16777215))

        self.horizontalLayout_28.addWidget(self.label_9)

        self.time_step = QSpinBox(self.Plots)
        self.time_step.setObjectName(u"time_step")
        self.time_step.setMaximumSize(QSize(100, 16777215))

        self.horizontalLayout_28.addWidget(self.time_step)


        self.horizontalLayout_31.addLayout(self.horizontalLayout_28)


        self.verticalLayout_18.addLayout(self.horizontalLayout_31)

        self.horizontalLayout_26 = QHBoxLayout()
        self.horizontalLayout_26.setObjectName(u"horizontalLayout_26")
        self.widget = QWidget(self.Plots)
        self.widget.setObjectName(u"widget")

        self.horizontalLayout_26.addWidget(self.widget)

        self.widget_2 = QWidget(self.Plots)
        self.widget_2.setObjectName(u"widget_2")

        self.horizontalLayout_26.addWidget(self.widget_2)

        self.widget_3 = QWidget(self.Plots)
        self.widget_3.setObjectName(u"widget_3")

        self.horizontalLayout_26.addWidget(self.widget_3)


        self.verticalLayout_18.addLayout(self.horizontalLayout_26)

        self.horizontalLayout_27 = QHBoxLayout()
        self.horizontalLayout_27.setObjectName(u"horizontalLayout_27")
        self.widget_4 = QWidget(self.Plots)
        self.widget_4.setObjectName(u"widget_4")

        self.horizontalLayout_27.addWidget(self.widget_4)

        self.widget_5 = QWidget(self.Plots)
        self.widget_5.setObjectName(u"widget_5")

        self.horizontalLayout_27.addWidget(self.widget_5)

        self.widget_6 = QWidget(self.Plots)
        self.widget_6.setObjectName(u"widget_6")

        self.horizontalLayout_27.addWidget(self.widget_6)


        self.verticalLayout_18.addLayout(self.horizontalLayout_27)

        self.tabWidget.addTab(self.Plots, "")

        self.verticalLayout_22.addWidget(self.tabWidget)


        self.retranslateUi(Dialog)

        self.tabWidget.setCurrentIndex(0)
        self.pushButton.setDefault(False)


        self.pushButton.clicked.connect(self.run_model)
        self.initialise_plots()
        self.time_step.valueChanged.connect(self.plot_figures)
        QMetaObject.connectSlotsByName(Dialog)
        
    # setupUi

    def retranslateUi(self, Dialog):
        Dialog.setWindowTitle(QCoreApplication.translate("Dialog", u"Dialog", None))
        self.label_17.setText(QCoreApplication.translate("Dialog", u"HipWear - Python Wrapper and GUI for Evaluting Wear on a Total Hip Replacement", None))
        self.label_36.setText(QCoreApplication.translate("Dialog", u"by Dr Joshua Montgomery (jm26774@essex.ac.uk) at the University of Essex", None))
        self.label_28.setText(QCoreApplication.translate("Dialog", u"Initalisation  Parameters", None))
        self.label_15.setText(QCoreApplication.translate("Dialog", u"nt1 - First", None))
        self.label_16.setText(QCoreApplication.translate("Dialog", u"nt2 - Final", None))
        self.label_37.setText(QCoreApplication.translate("Dialog", u"n_gts - Time steps per gait cycle", None))
        self.label_21.setText(QCoreApplication.translate("Dialog", u"ICASE - Inital Solution", None))
        self.label_26.setText(QCoreApplication.translate("Dialog", u"Relaxation Factors", None))
        self.label.setText(QCoreApplication.translate("Dialog", u"OMIGP - Pressure Relaxation", None))
        self.label_2.setText(QCoreApplication.translate("Dialog", u"OMIEX - X Load Relaxation", None))
        self.label_3.setText(QCoreApplication.translate("Dialog", u"OMIEY - Y Load Relaxation", None))
        self.label_4.setText(QCoreApplication.translate("Dialog", u"OMIEZ - Z Load Relaxation", None))
        self.label_40.setText(QCoreApplication.translate("Dialog", u"Load Acceleration Factors", None))
        self.label_6.setText(QCoreApplication.translate("Dialog", u"FACX - X Load Acceleration Factor", None))
        self.label_7.setText(QCoreApplication.translate("Dialog", u"FACY - Y Load Acceleration Factor", None))
        self.label_8.setText(QCoreApplication.translate("Dialog", u"FACZ - Z Load Acceleration Factor", None))
        self.label_27.setText(QCoreApplication.translate("Dialog", u"Convergence Factors", None))
        self.label_22.setText(QCoreApplication.translate("Dialog", u"ERRP_con - Pressure Convergence", None))
        self.label_23.setText(QCoreApplication.translate("Dialog", u"ERWX_con - W_X Covergence", None))
        self.label_24.setText(QCoreApplication.translate("Dialog", u"ERWY_con - W_Y Covergence", None))
        self.label_25.setText(QCoreApplication.translate("Dialog", u"ERWZ_com - W_Z Convergence", None))
        self.label_13.setText(QCoreApplication.translate("Dialog", u"n_W_circle - Maximum number of iterations before an error is thrown", None))
        self.label_41.setText(QCoreApplication.translate("Dialog", u" Acceleration Threshold", None))
        self.label_5.setText(QCoreApplication.translate("Dialog", u"ERRC - Error Threshold", None))
        self.label_29.setText(QCoreApplication.translate("Dialog", u"Material and Geometry", None))
        self.label_31.setText(QCoreApplication.translate("Dialog", u"E0 - Young's Modulus (MPA)", None))
        self.label_32.setText(QCoreApplication.translate("Dialog", u"R0 - Head Radius (mm)", None))
        self.label_33.setText(QCoreApplication.translate("Dialog", u"CR12 - Clearance (um)", None))
        self.label_35.setText(QCoreApplication.translate("Dialog", u"Wear", None))
        self.label_34.setText(QCoreApplication.translate("Dialog", u"alpha - Wear coefficient (10^-15)", None))
        self.label_30.setText(QCoreApplication.translate("Dialog", u"n_updt_intv - Interval for Wear Updates (million)", None))
        self.label_20.setText(QCoreApplication.translate("Dialog", u"n_updt - Wear Updating", None))
        self.pushButton.setText(QCoreApplication.translate("Dialog", u"Run Model", None))
        self.label_39.setText(QCoreApplication.translate("Dialog", u"Output Values", None))
        self.Output1.setText(QCoreApplication.translate("Dialog", u"Output 1 Disp", None))
        self.Output2.setText(QCoreApplication.translate("Dialog", u"Output 2 Disp", None))
        self.Output3.setText(QCoreApplication.translate("Dialog", u"Output 3 Disp", None))
        self.Output2_3.setText(QCoreApplication.translate("Dialog", u"Output 4 Disp", None))
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.inputs), QCoreApplication.translate("Dialog", u"Inputs", None))
        self.label_18.setText(QCoreApplication.translate("Dialog", u"HipWear - Python Wrapper and GUI for Evaluting Wear on a Total Hip Replacement", None))
        self.label_38.setText(QCoreApplication.translate("Dialog", u"by Dr Joshua Montgomery (jm26774@essex.ac.uk) at the University of Essex", None))
        self.label_9.setText(QCoreApplication.translate("Dialog", u"Time Step", None))
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.Plots), QCoreApplication.translate("Dialog", u"Plots", None))
    # retranslateUi

if __name__ == "__main__":
    app = QApplication(sys.argv)

    Dialog = QDialog()
    ui = Ui_Dialog()
    ui.setupUi(Dialog)
    Dialog.setWindowFlags(
        Qt.Window |
        Qt.WindowMinimizeButtonHint |
        Qt.WindowMaximizeButtonHint |
        Qt.WindowCloseButtonHint
    )
    Dialog.show()
    Dialog.adjustSize()

    sys.exit(app.exec())
