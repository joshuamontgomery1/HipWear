!C
!C       EHL and wear model of lubricated MoM hip replacement
!C       Code was initially created by Dr Leiming Gao ( Imperial College, Feb 2015)
!C       And then expanded and optimised by Dr Joshua Montgomery (University of Essex, 2026)
!C
module wear_model

contains

        subroutine run_wear_model(nt1, nt2, pmax_out, hmin_out, pmax_array_out, input_load, input_speed, &
                          omigp_in, omiex_in, omiey_in, omiez_in, facx_in, facy_in, facz_in, errp_con_in, &
                          erwx_con_in, erwy_con_in, erwz_con_in, errc_in, n_w_circle_in,cr12_in,r0_in,e0_in, &
                          alpha_in,n_updt_intv_in,n_updt,icase_in,n_gts_in)
        Use parameters
        Use H_coef
        Use sin_define
        use loading
        implicit none
        integer, intent(in) :: nt1, nt2
        real, intent(in) :: input_load, input_speed
        real, intent(in) :: omigp_in, omiex_in,omiey_in, omiez_in
        real, intent(in) :: facx_in, facy_in, facz_in
        real, intent(in) :: errp_con_in,erwx_con_in, erwy_con_in, erwz_con_in,errc_in
        integer,intent(in) :: n_w_circle_in
        real, intent(in) :: e0_in
        real, intent(in) :: r0_in
        real, intent(in) :: cr12_in
        real, intent(in) :: alpha_in
        integer, intent(in) :: n_updt
        real,intent(in) :: n_updt_intv_in
        integer,intent(in) :: icase_in
        integer,intent(in) :: n_gts_in
        real, intent(out) :: pmax_out
        real, intent(out) :: pmax_array_out(0:NA)
        real, intent(out) :: hmin_out

        integer :: NX(M), NY(M)
        integer :: MC(M)
        integer :: ICASE, NC, NT, NUMBER, KNUMBER
        integer :: I, J
        real :: X(M,0:NA), Y(M,0:NB)
        real :: DX(M), DY(M)
        real :: P(M,0:NA,0:NB)
        real :: H(M,0:NA,0:NB)
        !real :: XS(0:NA), YS(0:NB)
        real :: FP(M,0:NA,0:NB)
        real :: FGX(M), FGY(M), FGZ(M)
        real :: PS(0:NA,0:NB)
        real :: HS(0:NA,0:NB)
        real :: FPS(0:NA,0:NB)
        real :: PB(M,0:NA,0:NB)
        real :: POLD(0:NA,0:NB)
        real :: WWX(M), WWY(M), WWZ(M)
        real :: EPS(0:NA,0:NB)
        real :: RES(M,0:NA,0:NB)
        real :: RESD(0:NA,0:NB)
        real :: HT(0:NA,0:NB)
        real :: PT(0:NA,0:NB)
        real :: PXS(0:NA,0:NB)
        real :: PYS(0:NA,0:NB)
        real :: PZS(0:NA,0:NB)
        real :: FH(M,0:NA,0:NB)
        real :: FHS(0:NA,0:NB)


        real, allocatable :: EXT(:)
        real, allocatable :: EYT(:)
        real, allocatable :: EZT(:)
        real, allocatable :: HMIN(:,:)
        real, allocatable :: HCEN(:)
        real, allocatable :: PMAX(:)
        real, allocatable :: P_SIDE(:,:)
        real, allocatable :: P_ENTR(:,:)
        real, allocatable :: H_ENTR(:,:)
        real, allocatable :: H_SIDE(:,:)

        real :: WC_EX0(0:NA,0:NB)
        real :: WC_EX(M,0:NA,0:NB)
        real :: WC_EXS(0:NA,0:NB)
        real :: WC(0:NA,0:NB)
        !real :: WV(0:n_updt)
        real,allocatable :: WV(:)
        !real :: WV_CP(0:n_updt)
        real,allocatable :: WV_CP(:)
        real :: SURF(M,0:NA,0:NB)
        real :: SURFS(0:NA,0:NB)
        !real :: WD(0:n_updt)
        real,allocatable :: WD(:)
        real :: ETA(0:NA,0:NB)
        real :: GAMA(0:NA,0:NB)
        real :: PAV(0:NA,0:NB)
        real :: CP(0:NA,0:NB)
        real :: WC_A(0:NA,0:NB)

        real :: EX0, EY0, EZ0
        real :: VIS0, BETA
        real :: XIN, XOUT, YIN, YOUT
        real :: AL
        real :: ALPHA_E0
        real :: EPS1, EPS2
        real :: RAF
        real :: V_ALFA
        real :: ETA_INF
        real :: OMIGP, OMIEX, OMIEY, OMIEZ
        real :: ERRC
        real :: FACX, FACY, FACZ
        real :: DT, DYN
        real :: WX, WY, WZ
        real :: WXS, WYS, WZS
        real :: ERWX, ERWY, ERWZ
        real :: ERWX0, ERWY0, ERWZ0
        real :: PAV2
        integer :: ICX, ICY
        integer :: N_W_CIRCLE
        real :: N_UPDT_INTV

        integer :: MGAMA
        integer :: ISW
        integer :: MV0
        integer :: MV1
        integer :: MV2

        !real :: ERRP
        !real :: ERWX
        !real :: ERWY
        !real :: ERWZ
       ! real :: ERWX0
        !real :: ERWY0
        !real :: ERWZ0
        !real :: CONW

        integer :: NXS
        integer :: NYS
        integer :: NMIX
        real :: DXS
        real :: DYS

        real :: OX
        real :: OY
        real :: OZ
        real :: ERRP
        real :: CONW

        allocate(WV(0:n_updt))
        allocate(WV_CP(0:n_updt))
        allocate(WD(0:n_updt))

        n_gts = n_gts_in

        allocate(WXT(0:n_gts))
        allocate(WYT(0:n_gts))
        allocate(WZT(0:n_gts))
        allocate(T(0:n_gts))
        allocate(OXT(0:n_gts))
        allocate(OYT(0:n_gts))
        allocate(OZT(0:n_gts))

        allocate(EXT(0:n_gts))
        allocate(EYT(0:n_gts))
        allocate(EZT(0:n_gts))
        allocate(HMIN(0:n_gts,3))
        allocate(HCEN(0:n_gts))
        allocate(PMAX(0:n_gts))
        allocate(P_SIDE(0:n_gts,0:NA))
        allocate(P_ENTR(0:n_gts,0:NA))
        allocate(H_ENTR(0:n_gts,0:NB))
        allocate(H_SIDE(0:n_gts,0:NA))


        C1 = 0.0
        C2 = 0.0
        C3 = 0.0
        CS1 = 0.0
        CS2 = 0.0
        CS3 = 0.0
        ED = 0.0
        EDD = 0.0
        MDA = 0
        MDB = 0
        PL = 0.0
        DB = 0.0
        DB0 = 0.0
        DBS = 0.0
        DHDP = 0.0
        SINX  = 0.0
        COSX  = 0.0
        SINY  = 0.0
        COSY  = 0.0
        SINYM = 0.0
        SINYP = 0.0

        WXT = 0.0
        WYT = 0.0
        WZT = 0.0
        OXT = 0.0
        OYT = 0.0
        OZT = 0.0

        P      = 0.0
        H      = 0.0
        FP     = 0.0
        FGX    = 0.0
        FGY    = 0.0
        FGZ    = 0.0

        PS     = 0.0
        HS     = 0.0
        FPS    = 0.0
        PB     = 0.0
        POLD   = 0.0

        WWX    = 0.0
        WWY    = 0.0
        WWZ    = 0.0

        EPS    = 0.0
        RES    = 0.0
        RESD   = 0.0

        HT     = 0.0
        PT     = 0.0

        PXS    = 0.0
        PYS    = 0.0
        PZS    = 0.0

        FH     = 0.0
        FHS    = 0.0

        EXT    = 0.0
        EYT    = 0.0
        EZT    = 0.0

        HMIN   = 0.0
        HCEN   = 0.0
        PMAX   = 0.0

        P_SIDE = 0.0
        P_ENTR = 0.0
        H_ENTR = 0.0
        H_SIDE = 0.0

        WC_EX0 = 0.0
        WC_EX  = 0.0
        WC_EXS = 0.0
        WC     = 0.0

        WV     = 0.0
        WV_CP  = 0.0

        SURF   = 0.0
        SURFS  = 0.0

        WD     = 0.0

        ETA    = 0.0
        GAMA   = 0.0
        PAV    = 0.0
        CP     = 0.0
        WC_A   = 0.0

        NX     = 0
        NY     = 0
        MC     = 0


        ICASE=icase_in
        E0   = e0_in
        CR12 = cr12_in
        R0   = r0_in + CR12
        WRITE(*,*)'*** ICASE=',ICASE

           OPEN(15,FILE='Out_inf.DAT',STATUS='UNKNOWN')

           IF(ICASE==1) THEN

              OPEN(20,FILE='DATA1.D',STATUS='unknown',FORM='UNFORMATTED') !Initial guess of p h solutions
              OPEN(21,FILE='DATA2.D',STATUS='UNKNOWN',FORM='UNFORMATTED') !Output of p h as initial solutions for next time step
              READ(20) P,h,ex0,ey0,ez0

               CLOSE(20)
           else if (icase==2) then
              OPEN(20,FILE='DATA2.D',STATUS='unknown',FORM='UNFORMATTED') !Initial guess of p h solutions
              OPEN(21,FILE='DATA1.D',STATUS='UNKNOWN',FORM='UNFORMATTED') !Output of p h as initial solutions for next time step
              READ(20) P,h,ex0,ey0,ez0
               CLOSE(20)
           END IF

!        Open(51,file='wc6.dat')
!        open(52,file='wc_a.dat')
!        do j=0,nb
!          read(51,100) (wc_ex(m,i,j),i=0,na) ! previous surface profile
!          read(52,100) (wc_a(i,j),i=0,na) ! previous surface profile only due to wear, no creep
!        end do
!        close(51)
!        close (52)
!        wc_ex=wc_ex/cr12 !wc_ex must be dimensionless and used in subroutine 'filmth'

100     format(1000(1X,E14.5))

        CALL INPUT(VIS0,BETA,XIN,XOUT,YIN,YOUT,ICX,ICY,AL, &
                  n_updt_intv,alpha_E0,eps1,eps2,raf, &
                  v_alfa,eta_inf, n_W_circle, &
                  OMIGP,OMIEX,OMIEY,OMIEZ,ERRC,FACX,FACY,FACZ,&
                  OMIGP_IN,OMIEX_IN,OMIEY_IN,OMIEZ_IN,FACX_IN,FACY_IN,FACZ_IN,ERRC_IN, n_w_circle_in, &
                  alpha_in, n_updt_intv_in )

        CALL MGFACTOR(MGAMA,ISW,MV1,MV2,MV0)
        CALL MLGRID(X,Y,DX,DY,NX,NY,XIN,XOUT,YIN,YOUT)
        CALL SINCOS(X,Y,NX,NY)
        CALL COEF(DX,DY,NX,NY)
        !CALL rotation (v_rot3,theta,phi,nt)

        if(icase==0)  then
            call PGIVE(P,x,y)
             ex0=0
             ey0=1
             ez0=0
            OPEN(21,FILE='DATA1.D',STATUS='UNKNOWN',FORM='UNFORMATTED')
        end if

          Knumber=0
          pav2=0

        DO 2000 NC=1,n_updt

          WRITE(*,*)'*** NUMBER OF WORN SURFACE UPDATE=        ',NC
          WRITE(15,*)'*** NUMBER OF WORN SURFACE UPDATE=        ',NC

        wc=0
        pav=0

!        do i=0,na/2
!          do j=0,nb/2
!           wc_ex(m-1,i,j)=wc_ex(m,2*i,2*j) !wc_ex will be updated for each NC
!          end do
!        end do
!
!        if (m==3) then
!          do i=0,na/4
!          do j=0,nb/4
!           wc_ex(m-2,i,j)=wc_ex(m-1,2*i,2*j)
!          end do
!          end do
!        end if


        DO 1000 nt=nt1,nt2

        WRITE(*,*)'*** NUMBER OF TIME STEP=        ',nt
        WRITE(15,*)'*** NUMBER OF TIME STEP=        ',nt
        !if (nt>55) then
            !omigp=0.2 ! Converge faster after swing
        !end if


        dt=1.0/n_gts
        t(0)=0
        IF(nt.EQ.0) THEN
            DYN=0.           !For steady-state conditions
           ELSE
            DYN=1.           !For time-dependent conditions
        END IF
          wyt(0)=input_load
          oxt(0)=input_speed
          ox=oxt(nt)
          oy=oyt(nt)
          oz=ozt(nt)

          WY=wyt(nt)/(E0*R0*R0)
          wx=wxt(nt)/(E0*R0*R0)!
          WZ=WZt(nt)/(E0*R0*R0) !
        WRITE(*,*)'Speed ox=',ox,' oy=',oy,' oz=',oz
        WRITE(*,*)'Load  x=',wxt(nt),' y=',wyt(nt),' z=',wzt(nt),' N'

        !! For head wear: calculate head position at nt time step here
       ! do i=0,na/2
          !do j=0,nb/2
        !wh_ex(m-1,i,j)=wh_ex(m,2*i,2*j)
        !surfh(m-1,i,j)=surfh(m,2*i,2*j)
          !end do
       ! end do

       !if (m==3) then
       ! do i=0,na/4
          !do j=0,nb/4
        !wh_ex(m-2,i,j)=wh_ex(m-1,2*i,2*j)
        !surfh(m-2,i,j)=surfh(m-1,2*i,2*j)
         ! end do
      !  end do
      !end if

      DO  I=0,NX(M)
        DO  J=0,NY(M)
            FP(M,I,J)=-2.0*SINY(M,J)**2*H(M,I,J)/dt*DYN
            FH(M,I,J)=0.0
       END DO
     END DO
        FGX(M)=WX
        FGY(M)=WY
        FGZ(M)=WZ

        DO 500 NUMBER=1,n_W_circle  !! Maximum of number of 'W' circles

        POLD(0:NA,0:NB)=P(M,0:NA,0:NB)


       CALL CIRCLE(P,H,FP,FGz,FGY,FGX,DX,DY,NX,NY,MC,RES, &
            WWZ,WWY,WWX,PB,PS,HS,FPS,EPS,RESD, &
            PXS,PYS,pzs,EX0,EY0,EZ0,MV1,MV2,MV0, &
            AL,MGAMA,OMIGP,OMIEZ,OMIEY,OMIEX,ISW, &
            DYN,DT,ox,oy,oz,FH,FHS,EPS1,EPS2, &
            nmix,ERWY,wc_ex,wc_exs,surf,surfs, & !wh_ex,wh_exS,surfh,surfhs,
            eta,gama,vis0,eta_inf,v_alfa)

        CALL ERRORP(ERRP,P,POLD,NX,NY)
          NXS=NX(M)
          NYS=NY(M)
          DXS=DX(M)
          DYS=DY(M)

        Call LOAD(NXS,NYS,PS,PXS,PYS,pzs,DXS,DYS,WXS,WYS,wzs,m)
        CALL ERRORW(ERWX,ERWY,ERWZ,WX,WY,WZ,WXS,WYS,WZS, &
                   ERWX0,ERWY0,ERWZ0,CONW,FGX,FGY,FGZ)
          WRITE(*,*) ' WX=',wXs*conw,' WY=',WYS*conw,' WZ=',WZS*conw, 'N'
          if(wys*conw.gt.5000) then
           write(*,*) ' Load beyond 5kN'
           stop
          end if

         IF(ERRP.GT.ERRC.AND.ISW.EQ.0) THEN
        ISW=0
        ELSE
        ISW=1
        END IF

         IF(ISW.EQ.1) THEN
           write(*,*)'use factors'
           Ez0=Ez0-FACz*OMIEZ*ERWz0
           EY0=EY0-FACY*OMIEY*ERWY0
           EX0=EX0-FACX*OMIEX*ERWX0
         END IF

!         WRITE(15,335) NUMBER,ERRP,erwx,ERWY,ERWZ
         WRITE (*,335) NUMBER,ERRP,erwx,ERWY,ERWZ
  335    FORMAT(1X,' NUMBER=',I3,1X,'ERRP=',F10.6,/13X, &
             'ERWX=',F10.6,1X,'ERWY=',F10.6,1X,'ERWZ=',F10.6)
          IF(number.ge.3.and.(ERRP.LT.errp_con_in).AND.(ERWX.LT.erwx_con_in) &
          .AND.(ERWY.LT.erwy_con_in).AND.(ERWZ.LT.erwz_con_in)) GOTO 520

  500   CONTINUE
        knumber=knumber+1
        WRITE(15,*) '************Not converged*************'
        WRITE(15,335) NUMBER,ERRP,erwx,ERWY,ERWZ
  520   WRITE(*,*) '****** W circle finished ******'

        CALL DIMEN (P,PT,H,HT,ICX,ICY,H_SIDE,H_ENTR, &
            P_ENTR,p_side,nt,PMAX,HMIN,HCEN,EXT,EYT,EZT, &
            ex0,ey0,ez0,pav,hmin_out,pmax_array_out)
        CALL Wear(wc,alpha_E0,ps,ox,oy,oz,hs,eps2,raf,dt,eta,gama)

1000    continue

        call creep(cp,pav,nc,n_updt,n_updt_intv,wv_cp)
        CALL RESULT1(wd,wv,nc,n_updt,n_updt_intv,wc_ex,wc_ex0,wc_a,wc,cp)

2000    continue

        CALL RESULT2(X,Y,h_side,h_entr,nt1,nt2,T,HMIN,pt,ht,hcen,pmax, &
                     p_entr,p_side,wc,wd,wv,n_updt,wv_cp,wc_a)

        WRITE(15,*) 'Number of non-convergence',knumber
!        write(*,*) 'Time=', ETIME(TIME_USER_SYSTEM)
!        write(15,*) 'Time=', ETIME(TIME_USER_SYSTEM)
        WRITE(21) P,h,ex0,ey0,ez0
         CLOSE(15)
        CLOSE(21)

        pmax_out = maxval(PMAX)
        !pmax_array_out = p_array

        deallocate(WV)
        deallocate(WV_CP)
        deallocate(WD)

        deallocate(EXT)
        deallocate(EYT)
        deallocate(EZT)

        deallocate(HMIN)
        deallocate(HCEN)
        deallocate(PMAX)

        deallocate(P_SIDE)
        deallocate(P_ENTR)

        deallocate(H_SIDE)
        deallocate(H_ENTR)

        deallocate(WXT)
        deallocate(WYT)
        deallocate(WZT)

        deallocate(T)

        deallocate(OXT)
        deallocate(OYT)
        deallocate(OZT)


end subroutine run_wear_model

         SUBROUTINE CIRCLE(P,H,FP,FGz,FGY,FGX,DX,DY,NX,NY,MC,RES, &
             WWZ,WWY,WWX,PB,PS,HS,FPS,EPS,RESD, &
             PXS,PYS,pzs,EX0,EY0,ez0,MV1,MV2,MV0, &
             AL,MGAMA,OMIGP,OMIEZ,OMIEY,OMIEX,ISW, &
             DYN,DT,ox,oy,oz,FH,FHS,EPS1,EPS2, &
             nmix,ERWY,wc_ex,wc_exs,surf,surfs,& !wh_ex,wh_exS,surfh,surfhs,
             eta,gama,vis0,eta_inf,v_alfa)

            Use H_coef
            Use parameters


            implicit none
            integer :: NX(M), NY(M)
            integer :: MC(M)
            integer, intent(in) :: MV0
            integer, intent(in) :: MV1
            integer, intent(in) :: MV2
            integer, intent(in) :: MGAMA
            integer, intent(inout) :: ISW
            integer, intent(inout) :: NMIX
            real :: P(M,0:NA,0:NB)
            real :: H(M,0:NA,0:NB)
            real :: FP(M,0:NA,0:NB)
            real :: FGX(M)
            real :: FGY(M)
            real :: FGZ(M)
            real :: DX(M)
            real :: DY(M)
            real :: RES(M,0:NA,0:NB)
            real :: WWX(M)
            real :: WWY(M)
            real :: WWZ(M)
            real :: PB(M,0:NA,0:NB)
            real :: PS(0:NA,0:NB)
            real :: HS(0:NA,0:NB)
            real :: FPS(0:NA,0:NB)
            real :: EPS(0:NA,0:NB)
            real :: RESD(0:NA,0:NB)
            real :: PXS(0:NA,0:NB)
            real :: PYS(0:NA,0:NB)
            real :: PZS(0:NA,0:NB)
            real :: FH(M,0:NA,0:NB)
            real :: FHS(0:NA,0:NB)
            real :: WC_EX(M,0:NA,0:NB)
            real :: WC_EXS(0:NA,0:NB)
            real :: SURF(M,0:NA,0:NB)
            real :: SURFS(0:NA,0:NB)
            real :: ETA(0:NA,0:NB)
            real :: GAMA(0:NA,0:NB)
            real :: EX0
            real :: EY0
            real :: EZ0
            real :: AL
            real :: OMIGP
            real :: OMIEX
            real :: OMIEY
            real :: OMIEZ
            real :: DYN
            real :: DT
            real :: OX
            real :: OY
            real :: OZ
            real :: EPS1
            real :: EPS2
            real :: ERWY
            real :: VIS0
            real :: ETA_INF
            real :: V_ALFA
            integer :: K
!            integer :: K1
            integer :: KEY
            integer :: NXS
            integer :: NYS
            integer :: NXS1
            integer :: NYS1

          MC=0
          K=M
   20     NXS=NX(K)
          NYS=NY(K)
          KEY=1

          CALL SOLVER(P,H,FP,FGz,FGY,FGX,DX,DY,RES,WWZ,WWY,WWX, &
            HS,PS,FPS,EPS,RESD,PXS,PYS,pzs, &
            K,EX0,EY0,ez0,NXS,NYS,MV1,AL,OMIGP,OMIEZ,OMIEY,OMIEX, &
            KEY,ISW,ERWY, DYN,DT,ox,oy,oz, &
            FH,FHS,EPS1,EPS2,wc_ex,wc_exs,surf,surfs, & !wh_ex,wh_exS, surfh,surfhs,
            eta,gama,vis0,eta_inf,v_alfa)
         if(m.eq.1) goto 60
         MC(K)=MC(K)+1

        CALL RESTR(P,K,NX,NY)
        CALL RESTR(RES,K,NX,NY)
        CALL RESTR(H,K,NX,NY) !! FH CONCERNED


        PB(K-1,0:NX(K-1),0:NY(K-1))=P(K-1,0:NX(K-1),0:NY(K-1))

        NXS1=NX(K-1)
        NYS1=NY(K-1)

        CALL FUNCAL(FP,FGz,FGY,FGX,DX,DY,P,RES,WWZ,WWY,WWX, &
            PS,HS,EPS,FPS,PXS,PYS,pzs,K, &
            NXS1,NYS1,EX0,EY0,ez0,AL,    &
            DYN,dt,ox,oy,oz,H,FH,FHS,EPS1,EPS2, &
            wc_ex,wc_exs,surf,surfs, & !wh_ex,wh_exS,surfh,surfhs,
            eta,gama,vis0,eta_inf,v_alfa)

        K=K-1
        IF(K.GT.1) GOTO 20
        KEY=0
        NXS=NX(K)
        NYS=NY(K)

        CALL SOLVER(P,H,FP,FGz,FGY,FGX,DX,DY,RES,WWZ,WWY,WWX, &
            HS,PS,FPS,EPS,RESD,PXS,PYS,pzs, &
            K,EX0,EY0,ez0,NXS,NYS,MV0,AL,OMIGP,OMIEZ,OMIEY,OMIEX, &
            KEY,ISW,ERWY, DYN,dt,ox,oy,oz, &
            FH,FHS,EPS1,EPS2,wc_ex,wc_exs,surf,surfs, & !wh_ex,wh_exS, surfh,surfhs,
            eta,gama,vis0,eta_inf,v_alfa)

   50   CALL EXTEND(P,PB,NX,NY,RES,K)
        K=K+1
        NXS=NX(K)
        NYS=NY(K)

        CALL SOLVER(P,H,FP,FGz,FGY,FGX,DX,DY,RES,WWZ,WWY,WWX, &
            HS,PS,FPS,EPS,RESD,PXS,PYS,pzs, &
            K,EX0,EY0,ez0,NXS,NYS,MV2,AL,OMIGP,OMIEZ,OMIEY,OMIEX, &
            KEY,ISW,ERWY, DYN,dt,ox,oy,oz, &
            FH,FHS,EPS1,EPS2,wc_ex,wc_exs,surf,surfs, & !wh_ex,wh_exS, surfh,surfhs,
            eta,gama,vis0,eta_inf,v_alfa)

        IF(K.EQ.M) THEN
        WRITE(*,*) 'CYCLE ENDED'
        GOTO 60
        ELSE IF(MC(K).EQ.MGAMA) THEN
        MC(K)=0
        GOTO 50
        ELSE
        GOTO 20
        END IF
   60   RETURN
!
        Contains

        SUBROUTINE SOLVER(P,H,FP,FGz,FGY,FGX,DX,DY,RES,WWZ,WWY,WWX, &
            HS,PS,FPS,EPS,RESD,PXS,PYS,pzs, &
            K,EX0,EY0,ez0,NXS,NYS,MV,AL,OMIGP,OMIEZ,OMIEY,OMIEX, &
            KEY,ISW,ERWY, DYN,dt,ox,oy,oz, &
            FH,FHS,EPS1,EPS2,wc_ex,wc_exs,surf,surfs, & !wh_ex,wh_exS, surfh,surfhs,
            eta,gama,vis0,eta_inf,v_alfa)

        use H_coef
        use parameters
        implicit none
        integer :: K
        integer :: NXS
        integer :: NYS
        integer :: MV
        integer :: KEY
        integer :: ISW
        integer :: I
        integer :: J
        real :: EX0
        real :: EY0
        real :: EZ0
        real :: AL
        real :: OMIGP
        real :: OMIEZ
        real :: OMIEY
        real :: OMIEX
        real :: ERWY
        real :: DYN
        real :: DT
        real :: OX
        real :: OY
        real :: OZ
        real :: EPS1
        real :: EPS2
        real :: VIS0
        real :: ETA_INF
        real :: V_ALFA
        real :: P(M,0:NA,0:NB)
        real :: H(M,0:NA,0:NB)
        real :: FP(M,0:NA,0:NB)
        real :: FGX(M)
        real :: FGY(M)
        real :: FGZ(M)
        real :: DX(M)
        real :: DY(M)
        real :: RES(M,0:NA,0:NB)
        real :: WWX(M)
        real :: WWY(M)
        real :: WWZ(M)
        real :: HS(0:NA,0:NB)
        real :: PS(0:NA,0:NB)
        real :: FPS(0:NA,0:NB)
        real :: EPS(0:NA,0:NB)
        real :: RESD(0:NA,0:NB)
        real :: PXS(0:NA,0:NB)
        real :: PYS(0:NA,0:NB)
        real :: PZS(0:NA,0:NB)
        real :: FH(M,0:NA,0:NB)
        real :: FHS(0:NA,0:NB)
        real :: WC_EX(M,0:NA,0:NB)
        real :: WC_EXS(0:NA,0:NB)
        real :: SURF(M,0:NA,0:NB)
        real :: SURFS(0:NA,0:NB)
        real :: ETA(0:NA,0:NB)
        real :: GAMA(0:NA,0:NB)
        real :: ERRWY
        integer :: MCC
        integer :: KF
        integer :: KH
        real :: DXS
        real :: DYS
        real :: DXS2
        real :: DYS2
        real :: D00
        real :: D10
        real :: F1
        real :: F2
        real :: RESS
        real :: DLDP
        real :: DELT
        real :: WXS
        real :: WYS
        real :: WZS
        real :: ERRWX
!        real :: ERRWY_LOC
        real :: ERRWZ

         ps(0:nxs,0:nys)=p(k,0:nxs,0:nys)
         fps(0:nxs,0:nys)=fp(k,0:nxs,0:nys)
         fhs(0:nxs,0:nys)=fh(k,0:nxs,0:nys)
         wc_exs(0:nxs,0:nys)=wc_ex(k,0:nxs,0:nys)
         surfs(0:nxs,0:nys)=surf(k,0:nxs,0:nys)
      !   wh_exs(0:nxs,0:nys)=wh_ex(k,0:nxs,0:nys)
      !   surfhs(0:nxs,0:nys)=surfh(k,0:nxs,0:nys)

        CS1(KD+1:K,0:NL,0:NL)=C1(K,KD+1:K,0:NL,0:NL)
        CS2(KD+1:K,0:NL,0:NL)=C2(K,KD+1:K,0:NL,0:NL)
        CS3(KD+1:K,0:NL,0:NL)=C3(K,KD+1:K,0:NL,0:NL)
        DBS(0:NMA,0:NMB)=DB(K,0:NMA,0:NMB)

        DXS=DX(K)
        DYS=DY(K)
        DXS2=DXS**2
        DYS2=DYS**2
        D00=DHDP(K,1)
        D10=DHDP(K,2)

        DO 250 MCC=1,MV

        KH=1
        CALL FILMTH(HS,PS,EX0,EY0,ez0,NXS,NYS,K,FHS,KH,EPS1, &
                    wc_exs,surfs) !,wh_exs,surfhs
        call visc(k,eta,gama,ox,oy,oz,hs,vis0,eta_inf,v_alfa,nxs,nys)

        EPS(0:NXS,0:NYS)=HS(0:NXS,0:NYS)**3/(AL*ETA(0:NXS,0:NYS))
        PS(0:NXS,1)=0.0
        PS(0:NXS,NYS)=0.0

        DO 100 J=1,NYS-1
          PS(1,J)=0.0
          DO 90 I=1,NXS-1
           KF=1

          CALL SCHEME(k,F1,F2,EPS,PS,HS,DXS,DYS,DT,DYN,D00,D10,KF, &
                     I,J,DXS2,DYS2,ox,oy,oz,EPS1,EPS2,nxs,nys)

           RESS=FPS(I,J)-F1
           DLDP=F2
           DELT=RESS/DLDP

           PS(I,J)=PS(I,J)+OMIGP*DELT

          IF(PS(I,J).LT.0.0) PS(I,J)=0.0
   90     CONTINUE
          PS(NXS,J)=0.0
  100    CONTINUE

        CALL LOAD(NXS,NYS,PS,PXS,PYS,pzs,DXS,DYS,WXS,WYS,wzs,k)

        IF(K.EQ.1.AND.MOD(MCC,5).EQ.0.AND.ISW.EQ.0) THEN
        ERRWz=WzS-FGz(K)
        ERRWY=WYS-FGY(K)
        ERRWX=WXS-FGX(K)
        Ez0=Ez0-OMIEz*ERRWz
        EY0=EY0-OMIEY*ERRWY
        EX0=EX0-OMIEX*ERRWX
        END IF

250     CONTINUE

        IF((K.EQ.1).OR.(KEY.EQ.0)) GOTO 300
        CALL RESCAL(RESD,PS,HS,FPS,EPS,EX0,EY0,ez0,NXS,NYS,DXS,DYS,AL,K, &
            DYN,dt,ox,oy,oz,FHS,EPS1,EPS2,wc_exs,surfs, & !wh_exS,surfhs,
            eta,gama,vis0,eta_inf,v_alfa)

        RES(K,0:NXS,0:NYS)=RESD(0:NXS,0:NYS)
        WWz(K)=WzS
        WWY(K)=WYS
        WWX(K)=WXS

  300   P(K,0:NXS,0:NYS)=PS(0:NXS,0:NYS)
        H(K,0:NXS,0:NYS)=HS(0:NXS,0:NYS)

        END SUBROUTINE SOLVER


        SUBROUTINE RESCAL(RESD,PS,HS,FPS,EPS,EX0,EY0,ez0,NXS,NYS,DXS,DYS,AL,K,&
                  DYN,dt,ox,oy,oz, FHS,EPS1,EPS2,wc_exs,surfs, & !wh_exS,surfhs,
                  eta,gama,vis0,eta_inf,v_alfa)
        use H_coef
        use parameters
        implicit none
        integer :: K
        integer :: NXS, NYS
        integer :: I, J
        integer :: KH, KF
        real :: EX0, EY0, EZ0
        real :: DXS, DYS
        real :: DXS2, DYS2
        real :: AL
        real :: DYN
        real :: DT
        real :: OX, OY, OZ
        real :: EPS1, EPS2
        real :: VIS0, ETA_INF, V_ALFA
        real :: F1, F2
        real :: D00, D10
        real :: RESD(0:NA,0:NB)
        real :: PS(0:NA,0:NB)
        real :: HS(0:NA,0:NB)
        real :: FPS(0:NA,0:NB)
        real :: EPS(0:NA,0:NB)
        real :: FHS(0:NA,0:NB)
        real :: WC_EXS(0:NA,0:NB)
        real :: SURFS(0:NA,0:NB)
        real :: ETA(0:NA,0:NB)
        real :: GAMA(0:NA,0:NB)

        KH=0
        CALL FILMTH(HS,PS,EX0,EY0,ez0,NXS,NYS,K,FHS,KH,EPS1, &
            wc_exs,surfs) !wh_exs,surfhs

        call visc(k,eta,gama,ox,oy,oz,hs,vis0,eta_inf,v_alfa,nxs,nys)
        DXS2=DXS**2
        DYS2=DYS**2

        EPS(0:NXS,0:NYS)=HS(0:NXS,0:NYS)**3/AL
        RESD(0:NXS,0)=0.0
        RESD(0:NXS,NYS)=0.0

        KF=0
        DO J=1,NYS-1
        RESD(0,J)=0.0
        DO I=1,NXS-1
        CALL SCHEME(k,F1,F2,EPS,PS,HS,DXS,DYS,DT,DYN,D00,D10,KF, &
                   I,J,DXS2,DYS2,ox,oy,oz,EPS1,EPS2,nxs,nys)
        RESD(I,J)=FPS(I,J)-F1
        END DO
        RESD(NXS,J)=0.0
        END DO

        END SUBROUTINE RESCAL


        SUBROUTINE FUNCAL(FP,FGz,FGY,FGX,DX,DY,P,RES,WWZ,WWY,WWX, &
                  PS,HS,EPS,FPS,PXS,PYS,pzs,K, &
                  NXS1,NYS1,EX0,EY0,ez0,AL,    &
                  DYN,dt,ox,oy,oz,H,FH,FHS,EPS1,EPS2, &
                  wc_ex,wc_exs,surf,surfs, & !surfh,surfhs,wh_ex,wh_exs,
                  eta,gama,vis0,eta_inf,v_alfa)
        use H_coef
        use parameters
        implicit none
        integer :: K
        integer :: NXS1
        integer :: NYS1
        real :: EX0
        real :: EY0
        real :: EZ0
        real :: AL
        real :: DYN
        real :: DT
        real :: OX
        real :: OY
        real :: OZ
        real :: EPS1
        real :: EPS2
        real :: VIS0
        real :: ETA_INF
        real :: V_ALFA
        real :: FP(M,0:NA,0:NB)
        real :: FGX(M)
        real :: FGY(M)
        real :: FGZ(M)
        real :: P(M,0:NA,0:NB)
        real :: RES(M,0:NA,0:NB)
        real :: DX(M)
        real :: DY(M)
        real :: WWX(M)
        real :: WWY(M)
        real :: WWZ(M)
        real :: PS(0:NA,0:NB)
        real :: HS(0:NA,0:NB)
        real :: EPS(0:NA,0:NB)
        real :: FPS(0:NA,0:NB)
        real :: PXS(0:NA,0:NB)
        real :: PYS(0:NA,0:NB)
        real :: PZS(0:NA,0:NB)
        real :: FH(M,0:NA,0:NB)
        real :: FHS(0:NA,0:NB)
        real :: H(M,0:NA,0:NB)
        real :: WC_EX(M,0:NA,0:NB)
        real :: WC_EXS(0:NA,0:NB)
        real :: SURF(M,0:NA,0:NB)
        real :: SURFS(0:NA,0:NB)
        real :: ETA(0:NA,0:NB)
        real :: GAMA(0:NA,0:NB)
        integer :: I
        integer :: J
        integer :: K1
        integer :: KH
        integer :: KF
        real :: D00
        real :: D10
        real :: DXS
        real :: DYS
        real :: DXS2
        real :: DYS2
        real :: F1
        real :: F2
        real :: WXS
        real :: WYS
        real :: WZS
        K1=K-1

        DO  I=0,NXS1
        DO  J=0,NYS1
        PS(I,J)=P(K1,I,J)
        FHS(I,J)=0.0
        wc_exs(i,j)=wc_ex(k1,i,j)
        !wh_exs(i,j)=wh_ex(k1,i,j)
        surfs(i,j)=surf(k1,i,j)
        !surfhs(i,j)=surfh(k1,i,j)
        END DO
        END DO

        CS1(KD+1:K1,0:NL,0:NL)=C1(K1,KD+1:K1,0:NL,0:NL)
        CS2(KD+1:K1,0:NL,0:NL)=C2(K1,KD+1:K1,0:NL,0:NL)
        CS3(KD+1:K1,0:NL,0:NL)=C3(K1,KD+1:K1,0:NL,0:NL)
        DBS(0:NMA,0:NMB)=DB(K1,0:NMA,0:NMB)

        DXS=DX(K1)
        DXS2=DXS**2
        DYS=DY(K1)
        DYS2=DYS**2

        KH=0
        CALL FILMTH(HS,PS,EX0,EY0,ez0,NXS1,NYS1,K1,FHS,KH,EPS1, &
            wc_exs,surfs) !wh_exs,surfhs,
          FHS(0:NXS1,0:NYS1)=H(K1,0:NXS1,0:NYS1)-HS(0:NXS1,0:NYS1)

     !   KH=1
        !CALL FILMTH(HS,PS,EX0,EY0,ez0,NXS1,NYS1,K1,FHS,KH,EPS1, &
     !       wc_exs,wh_exs,surfs,surfhs)

          call visc(k1,eta,gama,ox,oy,oz,hs,vis0,eta_inf,v_alfa,nxs1,nys1)

        EPS(0:NXS1,0:NYS1)=HS(0:NXS1,0:NYS1)**3/AL

        FPS(0:NXS1,0)=0.0
        FPS(0:NXS1,NYS1)=0.0

        KF=0
      DO  J=1,NYS1-1
        FPS(0,J)=0.0
        DO  I=1,NXS1-1

         CALL SCHEME(k1,F1,F2,EPS,PS,HS,DXS,DYS,DT,DYN,D00,D10,KF, &
                   I,J,DXS2,DYS2,ox,oy,oz,EPS1,EPS2,nxs,nys)
         FPS(I,J)=RES(K1,I,J)+F1
        END DO
        FPS(NXS1,J)=0.0
      END DO

        CALL LOAD(NXS1,NYS1,PS,PXS,PYS,pzs,DXS,DYS,WXS,WYS,wzs, k1)

        FGz(K1)=WzS+FGz(K)-WWz(K)
        FGY(K1)=WYS+FGY(K)-WWY(K)
        FGX(K1)=WXS+FGX(K)-WWX(K)

        FP(K1,0:NXS1,0:NYS1)=FPS(0:NXS1,0:NYS1)
        FH(K1,0:NXS1,0:NYS1)=FHS(0:NXS1,0:NYS1)

        END SUBROUTINE FUNCAL


        SUBROUTINE FILMTH(HS,PS,EX0,EY0,ez0,NXS,NYS,ML,FHS,KH,EPS1, &
                          wc_exs,surfs) !,wh_exs,surfhs
        use H_coef
        use parameters
        implicit none
        integer :: NXS, NYS
        integer :: ML
        integer :: KH
        integer :: I, J
        integer :: KK, L
        integer :: MX, MY
        real :: EX0, EY0, EZ0
        real :: EPS1
        real :: HS(0:NA,0:NB)
        real :: PS(0:NA,0:NB)
        real :: FHS(0:NA,0:NB)
        real :: WC_EXS(0:NA,0:NB)
        real :: SURFS(0:NA,0:NB)
        real :: SINXS(0:NA)
        real :: COSXS(0:NA)
        real :: SINYS(0:NB)
        real :: COSYS(0:NB)
        real :: SINYMS(1:NB-1)
        real :: SINYPS(1:NB-1)

        call sincos_s(ML,nxs,nys,sinxs,cosxs,sinys,cosys,sinyms,sinyps)

        IF(ML.LE.KD) THEN
        DO 40 I=0,NXS
        DO 30 J=0,NYS
        HS(I,J)=0.0
        DO 20 KK=0,NXS
        DO 10 L=0,NYS
        MX=IABS(I-KK)
        MY=IABS(J-L)
        HS(I,J)=HS(I,J)+DBS(MX,MY)*PS(KK,L)
   10   CONTINUE
   20   CONTINUE
   30   CONTINUE
   40   CONTINUE

        ELSE
        CALL ELMIML(HS,PS,ML,NXS,NYS)
        END IF

        do i=0,nxs
          do j=0,nys
               HS(I,J)=1.0-EX0*SINYS(J)*COSXS(I) &
                  -EY0*SINYS(J)*SINXS(I)-ez0*cosys(j) &
                  +HS(i,j)+FHS(I,J)+surfs(i,j)+wc_exs(I,J)! +surfhs(i,j)+wh_exs(i,j)
            end do
        end do

        IF (KH.EQ.1) THEN
        do i=0,na
          do j=0,nb
          if(HS(I,J).le.eps1) then
              hs(i,j)=eps1
          end if
          end do
         end do
        END IF

        END SUBROUTINE FILMTH

        END SUBROUTINE CIRCLE


        SUBROUTINE MLGRID(X,Y,DX,DY,NX,NY,XIN,XOUT,YIN,YOUT)
        use H_coef
        use parameters
        implicit none
        real :: X(M,0:NA)
        real :: Y(M,0:NB)
        real :: DX(M)
        real :: DY(M)
        integer :: NX(M)
        integer :: NY(M)
        real :: XIN
        real :: XOUT
        real :: YIN
        real :: YOUT
        integer :: K
        integer :: I
        integer :: LA
        integer :: MM
        integer :: NDA
        integer :: NDB
        real :: FAC
        NX(M)=NA
        NY(M)=NB

        DO 10 K=M-1,1,-1
        NX(K)=NX(K+1)/2
        NY(K)=NY(K+1)/2
   10   CONTINUE
        DO 20 K=1,M
        DX(K)=(XOUT-XIN)/NX(K)
        DY(K)=(YOUT-YIN)/NY(K)
   20   CONTINUE
        DO 50 K=1,M
        DO 30 I=0,NX(K)
        X(K,I)=XIN+DX(K)*I
   30   CONTINUE
        DO 40 I=0,NY(K)
        Y(K,I)=YIN+DY(K)*I
   40   CONTINUE
   50   CONTINUE

        MM=5
        FAC=0.5
        DO  LA=KD+1,M
         NDA=NX(LA)
         NDB=NY(LA)
         MDA(LA)=INT(3+FAC*LOG(NDA+1.0)+MM)
         MDB(LA)=INT(3+FAC*LOG(NDB+1.0)+MM)
        END DO
        END


        SUBROUTINE EXTEND(P,PB,NX,NY,DP,K)
        use parameters
        implicit none
        integer :: K
        integer :: I, J
        integer :: NX(M)
        integer :: NY(M)
        real :: P(M,0:NA,0:NB)
        real :: PB(M,0:NA,0:NB)
        real :: DP(M,0:NA,0:NB)
        DO 20 I=0,NX(K)
        DO 10 J=0,NY(K)
        DP(K,I,J)=P(K,I,J)-PB(K,I,J)
   10   CONTINUE
   20   CONTINUE
        CALL INTER(DP,K,NX,NY)
        DO 50 I=0,NX(K+1)
        DO 30 J=0,NY(K+1)
        P(K+1,I,J)=P(K+1,I,J)+DP(K+1,I,J)
   30   CONTINUE
   50   CONTINUE
        END


        SUBROUTINE INTER(U,K,NX,NY)
        use parameters
        implicit none
        real :: U(M,0:NA,0:NB)
        integer :: K
        integer :: NX(M)
        integer :: NY(M)
        integer :: K1
        integer :: I
        integer :: J
        K1=K+1
        DO 20 I=0,NX(K)
        DO 10 J=0,NY(K)
        U(K1,2*I,2*J)=U(K,I,J)
   10   CONTINUE
   20   CONTINUE
        DO 40 J=0,NY(K1),2
        DO 30 I=1,NX(K1)-1,2
        U(K1,I,J)=0.5*(U(K1,I-1,J)+U(K1,I+1,J))
   30   CONTINUE
   40   CONTINUE
        DO 60 I=0,NX(K1),2
        DO 50 J=1,NY(K1)-1,2
        U(K1,I,J)=0.5*(U(K1,I,J-1)+U(K1,I,J+1))
   50   CONTINUE
   60   CONTINUE
        DO 80 I=1,NX(K1)-1,2
        DO 70 J=1,NY(K1)-1,2
        U(K1,I,J)=0.5*(U(K1,I-1,J)+U(K1,I+1,J))
   70   CONTINUE
   80   CONTINUE
        END


        SUBROUTINE RESTR(U,K,NX,NY)
        use parameters
        implicit none
        real :: U(M,0:NA,0:NB)
        integer :: K
        integer :: NX(M)
        integer :: NY(M)
        integer :: K1
        integer :: I
        integer :: J
        integer :: NI
        integer :: NJ
        integer :: NU
        integer :: ND
        K1=K-1
        DO 20 I=1,NX(K1)-1
        NI=2*I
        DO 10 J=1,NY(K1)-1
        NJ=2*J
        U(K1,I,J)=0.25*U(K,NI,NJ)+  &
                0.125*(U(K,NI+1,NJ)+U(K,NI-1,NJ)+ &
                       U(K,NI,NJ+1)+U(K,NI,NJ-1))+ &
               0.0625*(U(K,NI+1,NJ+1)+U(K,NI-1,NJ-1)+ &
                       U(K,NI+1,NJ-1)+U(K,NI-1,NJ+1))
   10   CONTINUE
   20   CONTINUE
        NU=NX(K)
        ND=NX(K1)
        DO 30 J=0,NY(K1)
        U(K1,0,J)=U(K,0,2*J)
        U(K1,ND,J)=U(K,NU,2*J)
   30   CONTINUE
        NU=NY(K)
        ND=NY(K1)
        DO 40 I=0,NX(K1)
        U(K1,I,0)=U(K,2*I,0)
        U(K1,I,ND)=U(K,2*I,NU)
   40   CONTINUE
        END

        SUBROUTINE LOAD(NXS,NYS,PS,PXS,PYS,pzs,DXS,DYS,WXS,WYS,wzs,k)
        use parameters
        implicit none
        integer :: K
        integer :: NXS, NYS
        integer :: I, J
        real :: DXS, DYS
        real :: WXS, WYS, WZS
        real :: PS(0:NA,0:NB)
        real :: PXS(0:NA,0:NB)
        real :: PYS(0:NA,0:NB)
        real :: PZS(0:NA,0:NB)
        real :: SINXS(0:NA)
        real :: COSXS(0:NA)
        real :: SINYS(0:NB)
        real :: COSYS(0:NB)
        real :: SINYMS(1:NB-1)
        real :: SINYPS(1:NB-1)
        call sincos_s(k,nxs,nys,sinxs,cosxs,sinys,cosys,sinyms,sinyps)

        DO 120 I=0,NXS
        DO 110 J=0,NYS
        PxS(I,J)=PS(I,J)*SINYS(J)*SINYS(J)*COSXS(I)
          PYS(I,J)=PS(I,J)*SINYS(J)*SINYS(J)*SINXS(I)
        Pzs(i,j)=ps(i,j)*sinys(j)*cosys(j)
  110   CONTINUE
  120   CONTINUE
        WXS=0.0
        WYS=0.0
        wzs=0.
        DO 20 I=1,NXS-1,2
        DO 10 J=1,NYS-1,2
        WXS=WXS+16.0*PXS(I,J) &
          +4.0*(PXS(I-1,J)+PXS(I+1,J)+PXS(I,J-1)+PXS(I,J+1)) &
          +PXS(I-1,J-1)+PXS(I+1,J-1)+PXS(I-1,J+1)+PXS(I+1,J+1)
        WYS=WYS+16.0*PYS(I,J) &
          +4.0*(PYS(I-1,J)+PYS(I+1,J)+PYS(I,J-1)+PYS(I,J+1)) &
          +PYS(I-1,J-1)+PYS(I+1,J-1)+PYS(I-1,J+1)+PYS(I+1,J+1)
        WzS=WzS+16.0*PzS(I,J) &
          +4.0*(PzS(I-1,J)+PzS(I+1,J)+PzS(I,J-1)+PzS(I,J+1)) &
          +PzS(I-1,J-1)+PzS(I+1,J-1)+PzS(I-1,J+1)+PzS(I+1,J+1)
   10   CONTINUE
   20   CONTINUE
        WXS=WXS*DXS*DYS/9.0
        WYS=WYS*DXS*DYS/9.0
        WzS=WzS*DXS*DYS/9.0
        END

        SUBROUTINE SINCOS(X,Y,NX,NY)
        use sin_define
        use parameters
        implicit none
        real :: X(M,0:NA)
        real :: Y(M,0:NB)
        integer :: NX(M)
        integer :: NY(M)
        integer :: K
        integer :: I
        integer :: J


        DO  K=1,M
        DO  I=0,NX(K)
        SINX(K,I)=SIN(X(K,I))
        COSX(K,I)=COS(X(K,I))
        end do
        end do

        DO  K=1,M
        DO  J=0,NY(K)
        SINY(K,J)=SIN(Y(K,J))
        cosY(K,J)=cos(Y(K,J))
        end do
        end do

        DO  K=1,M
        DO  J=1,NY(K)-1
        SINYM(K,J)=SIN(0.5*(Y(K,J-1)+Y(K,J)))
        SINYP(K,J)=SIN(0.5*(Y(K,J+1)+Y(K,J)))
        end do
        end do
        END


        SUBROUTINE MGFACTOR(MGAMA,ISW,MV1,MV2,MV0)

        implicit none
        integer :: MGAMA
        integer :: ISW
        integer :: MV1
        integer :: MV2
        integer :: MV0
        MGAMA=2
        ISW=0
        MV1=2
        MV2=1
        MV0=24
        END

        SUBROUTINE ERRORW(ERWX,ERWY,ERWZ,WX,WY,WZ,WXS,WYS,WZS, &
                  ERWX0,ERWY0,ERWZ0,CONW,FGX,FGY,FGZ)
        use parameters
        implicit none
        real :: ERWX
        real :: ERWY
        real :: ERWZ
        real :: ERWX0
        real :: ERWY0
        real :: ERWZ0
        real :: WX
        real :: WY
        real :: WZ
        real :: WXS
        real :: WYS
        real :: WZS
        real :: CONW
        real :: FGX(M)
        real :: FGY(M)
        real :: FGZ(M)
        conw=e0*r0**2
        IF(WZ.EQ.0) THEN
        ERWZ=wzs*conw*0.01
         ELSE
          ERWz=ABS((WZ-WzS)/WZ)
        END IF
        IF(WX.EQ.0) THEN
          ERWX=wxs*conw*0.01
         ELSE
          ERWX=ABS((Wx-WXS)/WX)
        END IF
        ERWY=ABS((WY-WYS)/WY)
        ERWz0=WzS-FGz(M)
        ERWY0=WYS-FGY(M)
        ERWX0=WXS-FGX(M)
          END

        SUBROUTINE ERRORP(ERRP,P,POLD,NX,NY)
        use parameters
        implicit none
        real :: ERRP
        real :: P(M,0:NA,0:NB)
        real :: POLD(0:NA,0:NB)
!        real :: D00
!        real :: D10
        integer :: NX(M)
        integer :: NY(M)
        integer :: I
        integer :: J
        real :: SUMP
        ERRP=0.0
        SUMP=0.0
        DO 280 I=0,NX(M)
        DO 270 J=0,NY(M)
        ERRP=ERRP+ABS(P(M,I,J)-POLD(I,J))
        SUMP=SUMP+P(M,I,J)
  270   CONTINUE
  280   CONTINUE
        ERRP=ERRP/SUMP
        END



        SUBROUTINE SCHEME(k,F1,F2,EPS,PS,HS,DXS,DYS,DT,DYN,D00,D10,KF, &
                         I,J,DXS2,DYS2,ox,oy,oz,EPS1,EPS2,nxs,nys)
        use parameters
        implicit none
        integer :: K
        integer :: KF
        integer :: I
        integer :: J
        integer :: NXS
        integer :: NYS
        real :: F1
        real :: F2
        real :: DXS
        real :: DYS
        real :: DXS2
        real :: DYS2
        real :: DT
        real :: DYN
        real :: D00
        real :: D10
        real :: OX
        real :: OY
        real :: OZ
        real :: EPS1
        real :: EPS2
        real :: EPS(0:NA,0:NB)
        real :: PS(0:NA,0:NB)
        real :: HS(0:NA,0:NB)
        real :: EPSXM
        real :: EPSXP
        real :: EPSYM
        real :: EPSYP
        real :: F3
        real :: F4
        real :: F5
        real :: F6
        real :: F7
        integer :: MIX1
        integer :: MIX2
        integer :: KOX
        integer :: KOZ
        real :: SINXS(0:NA)
        real :: COSXS(0:NA)
        real :: SINYS(0:NB)
        real :: COSYS(0:NB)
        real :: SINYMS(1:NB-1)
        real :: SINYPS(1:NB-1)
        call sincos_s(k,nxs,nys,sinxs,cosxs,sinys,cosys,sinyms,sinyps)

         mix1=1
         mix2=1
         if(HS(I,J).LE.eps1) then  ! Reduced Reynolds equation
         mix1=0
         end if
         if(oz.ge.0) then
         koz=1
         else
         koz=-1
         end if
         if(ox.le.0) then
          kox=1
         else
          kox=-1
         end if

         EPSXM=0.5*(EPS(I-1,J)+EPS(I,J))
         EPSXP=0.5*(EPS(I+1,J)+EPS(I,J))
         EPSYM=0.5*(EPS(I,J-1)+EPS(I,J))
         EPSYP=0.5*(EPS(I,J+1)+EPS(I,J))
         F1=(EPSXM*PS(I-1,J)-(EPSXM+EPSXP)*PS(I,J) &
                  +EPSXP*PS(I+1,J))/DXS2*MIX1 !&
         f7= +SINYS(J)*(EPSYM*SINYMS(J)*PS(I,J-1) &
                 -(EPSYM*SINYMS(J)+EPSYP*SINYPS(J))*PS(I,J) &
                  +EPSYP*SINYPS(J)*PS(I,J+1))/DYS2*MIX1 !&
          f3=-SINYS(J)**2*(HS(I,J)-HS(I-1,J))/DXS*koz*oz !&
          f4=+SINYS(J)**2*sinxs(i)*(HS(I,J)-HS(I,J-1))/DyS*kox*ox !&
          f5=+SINYS(J)*cosxs(i)*cosys(j)*(HS(I,J)-HS(I-1,J))/DXS*koz*ox !&
          f6=-sinys(j)**2*cosxs(i)*(HS(I,J)-HS(I,J-1))/DyS*kox*oy &
          +sinys(j)*sinxs(i)*cosys(j)*(HS(I,J)-HS(I-1,J))/DXS*koz*oy &
            -2.0*DYN*SINYS(J)**2*HS(I,J)/dt*MIX2
        IF(KF.EQ.1) THEN
        F2=-(EPSXM+EPSXP)/DXS2*MIX1 &
            -SINYS(J)*(EPSYM*SINYMS(J)+EPSYP*SINYPS(J))/DYS2*MIX1 &
            -SINYS(J)**2*(d00-d10)/DXS*koz*oz &
          +SINYS(J)**2*sinxs(i)*(d00-d10)/DyS*kox*ox &
          +SINYS(J)*cosxs(i)*cosys(j)*(d00-d10)/DXS*koz*ox &
          -sinys(j)**2*cosxs(i)*(d00-d10)/DyS*kox*oy &
          +sinys(j)*sinxs(i)*cosys(j)*(d00-d10)/DXS*koz*oy &
            -2.0*SINYS(J)**2*D00/dt*DYN*MIX2
        End if
        f1=f1+f3+f4+f5+f6+f7
        !print *, EPSXM,epsxp,ps(i,j),PS(I-1,J),PS(I+1,J)

        END

       Subroutine Wear(wc,alpha_E0,ps,ox,oy,oz,hs,eps2,raf,dt,eta,gama)
        use parameters
        implicit none
        real :: wc(0:NA,0:NB)
        real :: ps(0:NA,0:NB)
        real :: hs(0:NA,0:NB)
        real :: eta(0:NA,0:NB)
        real :: gama(0:NA,0:NB)
        real :: alpha_E0
        real :: ox
        real :: oy
        real :: oz
        real :: eps2
        real :: raf
        real :: dt
        integer :: i
        integer :: j
        real :: frc
        real :: vol(0:NA,0:NB)
!        real :: x(M,0:NA)
!        real :: y(M,0:NB)

        call fluid_vol(vol,ox,oy,oz,m,na,nb)

        do i=0,na
         do j=0,nb
            if(hs(i,j)<eps2) then
            !if(ps(i,j)>1e-6) then
                frc=0.3 !eta(i,j)*gama(i,j)/(ps(i,j)*E0)
            wc(i,j)=wc(i,j)+alpha_E0/cr12*ps(i,j)*vol(i,j)*dt* &
                    !sqrt(1+3*frc*frc)         ! friction function
                   (eps2/hs(i,j))**raf         !lambd ratio function

            end if
         end do
        end do
        end

        Subroutine creep(cp,pav,nc,n_updt,n_updt_intv,wv_cp)
        use sin_define
        use parameters
        implicit none
        integer :: nc
        integer :: n_updt
        real :: n_updt_intv
        real :: cp(0:NA,0:NB)
        real :: pav(0:NA,0:NB)
        real :: wv_cp(0:n_updt)
        integer :: i
        integer :: j
        integer :: n0
        real :: time
        real :: wv
        real :: area(0:NA,0:NB)
        real :: pav2(0:NA,0:NB)
        pav2=0.0
        !n0=n_updt_intv*(nc-1)
        time=n_updt_intv*1/60.0  !one sec in one cycle ![min]

        do i=0,na
        do j=0,nb
        pav2(i,j)=pav(i,j)/n_gts
        cp(i,j)=fcp*pav2(i,j)*log10(time)*th ![m]
        end do
        end do
        print *, 'maxcp=',maxval(cp),'maxpav=',maxval(pav2),'nupdate=', n_updt_intv
         wv=0
        do i=0,na
        do j=0,nb
        area(i,j)=(pi*r0)**2/(na*nb)*siny(m,j)
        wv=wv+cp(i,j)*area(i,j)
        end do
        end do
        wv_cp(nc)=wv ![mm^3] !accumulated wear volume due to creep
        end

        Subroutine fluid_vol(vol,ox,oy,oz,k,nxs,nys)
        use sin_define
        use parameters
        implicit none
        integer :: k
        integer :: nxs
        integer :: nys
        real :: ox
        real :: oy
        real :: oz
        real :: vol(0:NA,0:NB)
        integer :: i
        integer :: j
        real :: u_sita
        real :: u_fi
        real :: sinxs(0:nxs)
        real :: cosxs(0:nxs)
        real :: sinys(0:nys)
        real :: cosys(0:nys)
        real :: sinyms(1:nys-1)
        real :: sinyps(1:nys-1)

        call sincos_s(k,nxs,nys,sinxs,cosxs,sinys,cosys,sinyms,sinyps)
        do i=0,nxs
            do j=0,nys
            u_sita=-ox*R0*sinxs(i)+oy*R0*cosxs(i)
            u_fi=-ox*R0*cosxs(i)*cosys(j)-oy*R0*sinxs(i)*cosys(j) &
              +oz*R0*sinys(j)
            vol(i,j)=sqrt(u_sita**2+u_fi**2)
            end do
        end do

        end

        SUBROUTINE DIMEN (P,PT,H,HT,ICX,ICY,H_SIDE,H_ENTR, &
             P_ENTR,p_side,nt,PMAX,HMIN,HCEN,EXT,EYT,EZT, &
             ex0,ey0,ez0,pav,HM_out,p_array)
        use parameters
        implicit none
        integer :: l1,l2
        integer :: ICX
        integer :: ICY
        integer :: NT
        real :: P(M,0:NA,0:NB)
        real :: H(M,0:NA,0:NB)
        real :: PT(0:NA,0:NB)
        real :: HT(0:NA,0:NB)
        real, intent(inout) :: H_ENTR(:,:)
        real, intent(inout) :: H_SIDE(:,:)
        real, intent(inout) :: P_ENTR(:,:)
        real, intent(inout) :: P_SIDE(:,:)

        real, intent(inout) :: PMAX(:)
        real, intent(inout) :: HCEN(:)
        real, intent(inout) :: HMIN(:,:)
        real, intent(inout) :: EXT(:)
        real, intent(inout) :: EYT(:)
        real, intent(inout) :: EZT(:)

        real :: p_array(0:NA)
        real :: EX0
        real :: EY0
        real :: EZ0
        real :: PAV(0:NA,0:NB)
        integer :: I
        integer :: J
        integer :: ihm = 0
        integer :: jhm = 0
        integer :: IPM
        integer :: JPM
        real :: CONP
        real :: CONH
        real :: HM
        real,intent(out) :: HM_out
        real :: PM

        l1 = lbound(H_SIDE,1)
        l2 = lbound(H_SIDE,2)

        CONP=E0*1.0E-6
        CONH=CR12*1.0E+6
        DO 20  I=0,NA
        DO 10  J=0,NB
         PT(I,J)=P(M,I,J)*CONP
         HT(I,J)=H(M,I,J)*CONH
         pav(i,j)=pav(i,j)+pt(i,j)
10        CONTINUE
20        CONTINUE

        HM=HT(0,0)
        pm=0
!    loc_hm=maxloc(ht)
        DO I=0,NA
        DO J=0,NB
         IF(HM.GT.HT(I,J)) then
         HM=HT(I,J)
         ihm=i
         jhm=j
         END IF

         if(pm.lt.PT(i,j)) then
         pm=PT(i,j)
         ipm=i
         jpm=j
           end if

         END DO
         END DO
         WRITE(*,*) 'Pmax=',pm,'MPa','  Hmin=', hm,'um'
        HM_out=HM

        DO I=0,NA
        h_side(nt+l1,I+l2)=ht(I,icy)
        p_side(nt+l1,I+l2)=pt(I,icy)
        END DO
        DO  J=0,NB
        h_entr(nt+l1,J+l2)=HT(Icx,J)
        p_entr(nt+l1,J+l2)=pt(Icx,J)
        END DO
        p_array=P(M,0:NA,64)
        pmax(nt)=pm
        !pmax(nt,2)=ipm
        !pmax(nt,3)=jpm
        HMIN(nt,1)=HM
        HMIN(nt,2)=ihm
        HMIN(nt,3)=jhm
        HCEN(nt)=ht(icx,icy)
        ext(nt)=ex0*CR12*1.0E3  !! unit: mm
        eyt(nt)=ey0*CR12*1.0E3
        ezt(nt)=ez0*CR12*1.0E3

       END

      Subroutine RESULT1(wd,wv,nc,n_updt,n_updt_intv,wc_ex,wc_ex0,wc_a,wc,cp)
        use sin_define
        use parameters
        implicit none
        integer :: nc
        integer :: n_updt
        real :: n_updt_intv
        real :: wd(0:n_updt)
        real :: wv(0:n_updt)
        real :: wc_ex0(0:NA,0:NB)
        real :: wc_ex(M,0:NA,0:NB)
        real :: wc_a(0:NA,0:NB)
        real :: wc(0:NA,0:NB)
        real :: cp(0:NA,0:NB)
        integer :: i
        integer :: j
        real :: area(0:NA,0:NB)
        real :: wv1

        do i=0,na
        do j=0,nb
        area(i,j)=(pi*r0)**2/(na*nb)*siny(m,j)
        wc_a(i,j)=wc_a(i,j)+wc(i,j)*n_updt_intv
        wc_ex(m,i,j)=wc_a(i,j)+cp(i,j)/cr12
        end do
        end do
        print *, 'wd_max without creep =',maxval(wc_a)*cr12

        wv1=0
        do i=0,na
        do j=0,nb
           wv1=wv1+wc(i,j)*cr12*area(i,j)
        end do
        end do

        wd(nc)=maxval(wc_ex)*cr12 !maximum penetration_cup (m)
        wv(nc)=wv1*n_updt_intv ! wear volume per nc cycles_cup (m^3)

        if(nc.eq.1) then
        open(25,file='wc.dat')
         do j=0,nb
          write(25,600) (wc_ex(m,i,j)*cr12,i=0,na)
        end do
        close (25)
        end if

        if(nc.eq.40) then
        open(25,file='wc7.dat')
        do j=0,nb
          write(25,600) (wc_ex(m,i,j)*cr12,i=0,na)
        end do
        close (25)
        end if

        if(nc.eq.60) then
        open(25,file='wc8.dat')
        do j=0,nb
          write(25,600) (wc_ex(m,i,j)*cr12,i=0,na)
        end do
        close (25)
        end if

        if(nc.eq.80) then
        open(25,file='wc9.dat')
        do j=0,nb
          write(25,600) (wc_ex(m,i,j)*cr12,i=0,na)
        end do
        close (25)
        end if

        if(nc.eq.100) then
        open(25,file='wc10.dat')
        do j=0,nb
          write(25,600) (wc_ex(m,i,j)*cr12,i=0,na)
        end do
        close (25)
        end if

600     format(1000(1X,E14.5))
        END

        SUBROUTINE RESULT2(X,Y,h_side,h_entr,nt1,nt2,T,hmin,pt,ht,hcen,pmax, &
                           p_entr,p_side,wc,wd,wv,n_updt,wv_cp,wc_a)
        use parameters
        implicit none
        integer :: NT1
        integer :: NT2
        integer :: N_UPDT
        integer :: l1,l2
        real :: X(M,0:NA)
        real :: Y(M,0:NB)
        real :: PT(0:NA,0:NB)
        real :: HT(0:NA,0:NB)

        real, intent(inout) :: H_ENTR(:,:)
        real, intent(inout) :: H_SIDE(:,:)
        real, intent(inout) :: P_ENTR(:,:)
        real, intent(inout) :: P_SIDE(:,:)

        real, intent(inout) :: PMAX(:)
        real, intent(inout) :: HCEN(:)
        real, intent(inout) :: HMIN(:,:)

        real :: WC(0:NA,0:NB)
        real :: WC_A(0:NA,0:NB)
        real, intent(inout) :: T(:)

        real :: WD(0:n_updt)
        real :: WV(0:n_updt)
        real :: WV_CP(0:n_updt)
        integer :: I
        integer :: J
        integer :: KT
        real :: CONA

        l1 = lbound(H_SIDE,1)
        l2 = lbound(H_SIDE,2)

        OPEN(30,FILE='h_entr.DAT')
        OPEN(31,FILE='p_entr.DAT')
        OPEN(32,FILE='h_side.DAT')
        OPEN(33,FILE='p_side.DAT')
        OPEN(34,FILE='hmcpmax.DAT')
        OPEN(35,FILE='ph.DAT')
        open(36,file='wd_max.dat')
        open(37,file='wv.dat')
        open(38,file='wv_cp.dat')
        open(41,file='p.dat')
        open(42,file='h.dat')
        open(43,file='wc_a.dat')! wear profile without creep

        CONA=180.0/pi
        DO  J=0,NB
          WRITE(30,120) Y(M,j)*CONA,(h_entr(KT+l1,j+l2),KT=0,NT2)
          WRITE(31,120) Y(M,j)*CONA,(P_entr(KT+l1,j+l2),KT=0,NT2)
          write(35,*) Y(M,j)*CONA,p_entr(nt2+l1,j+l2),h_entr(nt2+l1,j+l2)
        end do
        DO  I=0,NA
          WRITE(32,120) X(M,I)*CONA,(h_side(KT+l1,I+l2),KT=0,NT2)
          WRITE(33,120) X(M,I)*CONA,(p_side(KT+l1,I+l2),KT=0,NT2)
        END DO

        DO  KT=nt1,NT2
          WRITE(34,140) T(KT),hmin(KT,1),hmin(KT,2),hmin(KT,3),pmax(kt)
        END DO

        do i=0,n_updt
          write(36,*) wd(i)
          write(37,*) wv(i)
          write(38,*) wv_cp(i)
        end do
  120   FORMAT(F14.5,1000(1X,E14.5))
  140   FORMAT(10(1X,F15.6))
        do j=0,nb
          write(41,600) (pt(i,j),i=0,na)
        end do
        do j=0,nb
          write(42,600) (ht(i,j),i=0,na)
          write(43,600) (wc_a(i,j),i=0,na)
        end do

600     format(1000(1X,E14.5))
        CLOSE(30)
        CLOSE(31)
        CLOSE(32)
        CLOSE(33)
        CLOSE(34)
        close(35)
        close(36)
        close(37)
        close(38)
        END

        Subroutine visc(k,eta,gama,ox,oy,oz,hs,vis0,eta_inf,v_alfa,nxs,nys)
        use sin_define
        use parameters
        implicit none
        integer :: k
        integer :: nxs, nys
        integer :: i, j
        real :: ox, oy, oz
        real :: vis0
        real :: eta_inf
        real :: v_alfa
        real :: eta(0:na,0:nb)
        real :: gama(0:na,0:nb)
        real :: hs(0:na,0:nb)
        real :: vol(0:na,0:nb)

        call fluid_vol(vol,ox,oy,oz,k,nxs,nys)
        do i=0,nxs
        do j=0,nys
        gama(i,j)=vol(i,j)/(hs(i,j)*cr12)
        eta(i,j)=eta_inf +(vis0-eta_inf)/(1+v_alfa*(gama(i,j))**0.73)
        end do
        end do

        end


        SUBROUTINE PGIVE(P,x,y)
        use parameters
        implicit none
        integer :: I, J
        real :: XX
        real :: ZZ
        real :: T
        real :: P(M,0:NA,0:NB)
        real :: X(M,0:NA)
        real :: Y(M,0:NB)
        do i=0,na
        do j=0,nb
          xx=sin(y(m,j))*cos(x(m,i))
          zz=cos(y(m,j))
          t=0.2**2-xx**2-zz**2
          if(t.ge.1e-10) then
           p(m,i,j)=1e6/E0*sqrt(t)
          else
           p(m,i,j)=0
          end if
        end do
        end do
     !   p(m,1:na,1:nb)=1e5/E0
        END

        Subroutine sincos_s(k,nxs,nys,sinxs,cosxs,sinys,cosys,sinyms,sinyps)
        use sin_define
        use parameters

        implicit none
        integer :: k
        integer :: nxs
        integer :: nys
        real :: sinxs(0:nxs)
        real :: cosxs(0:nxs)
        real :: sinys(0:nys)
        real :: cosys(0:nys)
        real :: sinyms(1:nys-1)
        real :: sinyps(1:nys-1)

        !Dimension SINXS(0:NA),COSXS(0:NA),SINYS(0:NB),cosys(0:NB),SINYMS(1:NB-1),SINYPS(1:NB-1)
        SINXS(0:NXS)=SINX(K,0:NXS)
        COSXS(0:NXS)=COSX(K,0:NXS)
        SINYS(0:NYS)=SINY(K,0:NYS)
        cosys(0:NYS)=cosy(k,0:NYS)

        SINYMS(1:NYS-1)=SINYM(K,1:NYS-1)
        SINYPS(1:NYS-1)=SINYP(K,1:NYS-1)

   end

end module wear_model
