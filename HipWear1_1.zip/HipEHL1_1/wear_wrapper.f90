module wear_wrapper

use wear_model
use parameters

private
public :: wear_run

contains

subroutine wear_run (nt1,nt2,pmax, hmin,pmax_array,&
                        omigp_in, omiex_in, omiey_in, omiez_in, facx_in, facy_in, facz_in, errp_con_in, &
                        erwx_con_in, erwy_con_in, erwz_con_in, errc_in, n_w_circle_in,cr12_in,r0_in,e0_in,&
                        alpha_in, n_updt_intv_in,n_updt,icase_in,n_gts_in)

real, intent(out) :: pmax
real, intent(out) :: pmax_array(0:NA)
real, intent(out) :: hmin
integer, intent(in) :: nt1,nt2
real :: input_load=300.0
real :: input_speed=-2.0
real, intent(in) :: omigp_in, omiex_in,omiey_in, omiez_in
real, intent(in) :: facx_in, facy_in, facz_in
real, intent(in) :: errp_con_in,erwx_con_in, erwy_con_in, erwz_con_in,errc_in
real, intent(in) :: e0_in
real, intent(in) :: r0_in
real, intent(in) :: cr12_in
integer,intent(in) :: n_w_circle_in
integer,intent(in) :: n_updt
real, intent(in) :: alpha_in
real,intent(in) :: n_updt_intv_in
integer,intent(in) :: icase_in
integer, intent(in) :: n_gts_in

call run_wear_model(nt1, nt2, pmax, hmin,pmax_array,input_load,input_speed,&
                        omigp_in, omiex_in, omiey_in, omiez_in, facx_in, facy_in, facz_in, errp_con_in, &
                        erwx_con_in, erwy_con_in, erwz_con_in, errc_in, n_w_circle_in,cr12_in,r0_in,e0_in, &
                        alpha_in, n_updt_intv_in,n_updt,icase_in,n_gts_in )

end subroutine wear_run

end module wear_wrapper
