    SUBROUTINE COEF(DX,DY,NX,NY)
        use H_coef
        use parameters
        implicit none
        !DIMENSION DX(M),DY(M),NX(M),NY(M)
        real :: DX(M), DY(M)
        integer :: NX(M), NY(M)
        integer :: I, J
        integer :: LA, LLA
        integer :: NXS, NYS
        integer :: NMX, NMY
        integer :: NTA, NTB
        integer :: IM1, IM3
        integer :: IP1, IP3
        integer :: JM1, JM3
        integer :: JP1, JP3

       DO 210 LLA=M,1,-1
       NXS=NX(LLA)
       NYS=NY(LLA)
       DO I=0,NMA
         DO J=0,NMB
           DB(LLA,I,J)=DB0(LLA,I,J)
         END DO
       END DO

        NMX=NX(LLA)+4*2**(LLA-KD)
        NMY=NY(LLA)+4*2**(LLA-KD)

        IF(LLA.LE.KD) GOTO 210
        NTA=NMX/2
        NTB=NMY/2
        DO 50 LA=LLA-1,KD,-1
        DO 40  I=0,NTA
        DO 30  J=0,NTB
        DB(LA,I,J)=DB(LA+1,2*I,2*J)
   30   CONTINUE
   40   CONTINUE
        NTA=NTA/2
        NTB=NTB/2
   50   CONTINUE
        DO 180 LA=KD+1,LLA
        DO 70 I=0,NL,2
        DO 60 J=0,NL,2
        C1(LLA,LA,I,J)=0.0
   60   CONTINUE
   70   CONTINUE

        DO 90 I=1,NL-1,2
        IM1=IABS(I-1)
        IP1=I+1
        IM3=IABS(I-3)
        IP3=I+3
        DO 80 J=0,NL,2
        C1(LLA,LA,I,J)=DB(LA,I,J)     &
            -9.0*(DB(LA,IP1,J)+DB(LA,IM1,J))/16.0     &
            +1.0*(DB(LA,IP3,J)+DB(LA,IM3,J))/16.0
   80   CONTINUE
   90   CONTINUE
        DO 110 J=1,NL-1,2
        JM1=IABS(J-1)
        JP1=J+1
        JM3=IABS(J-3)
        JP3=J+3
        DO 100 I=0,NL,2
        C1(LLA,LA,I,J)=DB(LA,I,J)     &
            -9.0*(DB(LA,I,JP1)+DB(LA,I,JM1))/16.0     &
            +1.0*(DB(LA,I,JP3)+DB(LA,I,JM3))/16.0
  100   CONTINUE
  110   CONTINUE
        DO 130 I=1,NL-1,2
        IM1=IABS(I-1)
        IP1=I+1
        IM3=IABS(I-3)
        IP3=I+3
        DO 120 J=1,NL-1,2
        JM1=IABS(J-1)
        JP1=J+1
        JM3=IABS(J-3)
        JP3=J+3
        C1(LLA,LA,I,J)=DB(LA,I,J)     &
       -81.0*(DB(LA,IP1,JP1)+DB(LA,IM1,JP1)+DB(LA,IP1,JM1)     &
            +DB(LA,IM1,JM1))/256.0     &
       +9.0*(DB(LA,IP1,JP3)+DB(LA,IM1,JP3)+DB(LA,IP3,JP1)     &
            +DB(LA,IM3,JP1)+DB(LA,IP3,JM1)+DB(LA,IM3,JM1)     &
            +DB(LA,IP1,JM3)+DB(LA,IM1,JM3))/256.0     &
       -1.0*(DB(LA,IP3,JP3)+DB(LA,IM3,JP3)+DB(LA,IP3,JM3)     &
            +DB(LA,IM3,JM3))/256.0
  120   CONTINUE
  130   CONTINUE
        DO 150 I=0,NL
        IM1=IABS(I-1)
        IP1=I+1
        IM3=IABS(I-3)
        IP3=I+3

        DO 140 J=0,NL
        C2(LLA,LA,I,J)=DB(LA,I,J)     &
            -9.0*(DB(LA,IM1,J)+DB(LA,IP1,J))/16.0     &
            +1.0*(DB(LA,IM3,J)+DB(LA,IP3,J))/16.0
  140   CONTINUE
  150   CONTINUE
        DO 170 J=0,NL
        JM1=IABS(J-1)
        JP1=J+1
        JM3=IABS(J-3)
        JP3=J+3
        DO 160 I=0,NL
        C3(LLA,LA,I,J)=DB(LA,I,J)     &
            -9.0*(DB(LA,I,JM1)+DB(LA,I,JP1))/16.0     &
            +1.0*(DB(LA,I,JM3)+DB(LA,I,JP3))/16.0
  160   CONTINUE
  170   CONTINUE
  180   CONTINUE
        DO 200 I=0,NMX
        DO 190 J=0,NMY
        DB(LLA,I,J)=DB(KD,I,J)
  190   CONTINUE
  200   CONTINUE
  210   CONTINUE
    END

