""" 
This script is to demonstrate the plotting of the outputs
"""

import numpy as np
import pandas as pd
import os
import matplotlib.pyplot as plt

radius=16
pwd = os.getcwd()
file_wd=pwd+"\\2nd cycle\\"
cross_section=64
time_step=10

# %% Linear wear contour
#Wear without creep

wc_a = pd.read_fwf(file_wd+"wc_a.dat",header=None)

Z = wc_a.to_numpy()

x = np.linspace(-radius, radius, wc_a.shape[0])
y = np.linspace(-radius, radius, wc_a.shape[1])

X, Y = np.meshgrid(x, y)

plt.contourf(X, Y, Z, levels=50, cmap="viridis")
cbar=plt.colorbar()
plt.title("Wear Without Creep")
cbar.set_label('Wear (nm)')
plt.xlabel("X (mm)")
plt.ylabel("Y (mm)")
plt.show()

# %% Volumetric Wear Against Time
plt.figure()
wv = pd.read_fwf(file_wd+"wv.dat",header=None)
plt.plot(wv)
plt.ylabel("Volumetric Wear ($m^3$)")
plt.xlabel("Wear Cycles (million)")
plt.title("Volumetric Wear Against Time")
plt.show()

# %% Creep of Acetabular Cup
plt.figure()
wv_cp = pd.read_fwf(file_wd+"wv_cp.dat",header=None)
plt.plot(wv_cp)
plt.ylabel("Creep (m)")
plt.xlabel("Wear Cycles (million)")
plt.title("Creep of Acetabular Cup")
plt.show()

# %% Max Pressure
plt.figure()
hmcpmax = pd.read_fwf(file_wd+"hmcpmax.dat",header=None)
plt.plot(hmcpmax.iloc[:,4])
plt.ylabel("Pressure (MPa)")
plt.xlabel("Cycle Timestep")
plt.title("Maximum Pressure Across 1 Cycle")
plt.show()

# %% Min Film
plt.figure()
hmcpmax = pd.read_fwf(file_wd+"hmcpmax.dat",header=None)
plt.plot(hmcpmax.iloc[:,1])
plt.ylabel("Film Thickness (nm)")
plt.xlabel("Cycle Timestep")
plt.title("Minimum Film Across 1 Cycle")
plt.show()

# %% Pressure Distribution
plt.figure()
p_entr = pd.read_fwf(file_wd+"p_entr.dat",header=None)
p_side = pd.read_fwf(file_wd+"p_side.dat",header=None)
x=np.linspace(-radius,radius,p_entr.iloc[:,time_step].size)
plt.plot(x,p_entr.iloc[:,time_step])
plt.ylabel("Pressure (MPa)")
plt.xlabel("X Position (mm)")
plt.title("Cross Section of Pressure at timestep: "+str(time_step))
plt.show()



