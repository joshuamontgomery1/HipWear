        SUBROUTINE INPUT(VIS0,BETA,XIN,XOUT,YIN,YOUT,ICX,ICY,AL,  &
                  n_updt_intv,alpha_E0,eps1,eps2,raf,  &
                  v_alfa,eta_inf,n_W_circle, &
                  OMIGP,OMIEX,OMIEY,OMIEZ,ERRC,FACX,FACY,FACZ,&
                  OMIGP_IN,OMIEX_IN,OMIEY_IN,OMIEZ_IN,FACX_IN,FACY_IN,FACZ_IN,ERRC_IN, n_w_circle_in, &
                  alpha_in, n_updt_intv_in )
        Use H_coef
        Use loading

        beta=0.              !Cup inclination angle
        XIN=beta/180.*pi     !Computing domain
        XOUT=PI+xin
        YIN=0.0
        YOUT=PI
        ICX=nint((0.5 - xin/pi)*NA) !Series number of the mesh node at the contact centre
        ICY=NB/2
                   !Elastic modulus (only used as scaling parameter)
        AL=(6.0*R0*R0)/(CR12*CR12*E0) !Parameter used in non-dimensional Reynolds equation

        write(15,*)'Radial clearance=',cr12
        write(15,*)'inclination angle=',beta,'degree.',' icx=',icx
        n_updt_intv=n_updt_intv_in      !interval (No. of cycles) for geometry update
        ALPHA=alpha_in         !linear wear factor
        Alpha_E0=alpha*E0

        EPS1=20e-9/cr12         !Boundary film thickness
        EPS2=Ra/cr12
        raf=1                !power factor of (Ra/h)

        vis0=0.0009

        eta_inf=vis0
        v_alfa=9.54

        n_W_circle=n_w_circle_in
        OMIGP=OMIGP_IN !0.005-0.05
        OMIEX=OMIEX_IN
        OMIEY=OMIEY_IN
        OMIEZ=OMIEZ_IN
        ERRC=ERRC_IN
        FACX=FACX_IN
        FACY=FACY_IN
        FACZ=FACZ_IN
        write(15,*)'Vis0=',vis0
        write(15,*) 'Power factor of (Ra/h) = ',raf
        write(15,*) 'Boundary film thickness = ',Ra
        write(15,*) 'Wear factor= ',alpha
        write(15,*) 'n_updt_intv= ',n_cycle_intv

!        open(30,file='ISO_FV.dat')
        open(30,file='BM30.dat')
        do i=1,n_gts
          read(30,*) T(i),wxt(i),wyt(i),wzt(i),oxt(i),oyt(i),ozt(i)
        end do
        close(30)

      open(61,file='SS32.txt')
      open(62,file='SS64.txt')
      open(63,file='SS128.txt')
        m1=na
        k1=m
      do while (k1>0)
        do i=0,m1
        do j=0,m1
          read(60+k1,*) DB0(k1,i,j)
        end do
        end do
        k1=k1-1
        m1=m1/2
      end do

      DB0=DB0*E0/CR12   !non-dimensional

      CLOSE(61)
      CLOSE(62)
      CLOSE(63)
      k1=m
      do while (k1>0)
        DHDP(k1,1)=DB0(k1,0,0)  !ss_64(1)*E0/cr
        DHDP(k1,2)=DB0(k1,0,1)  !ss_64(2)*E0/cr
        k1=k1-1
      end do
      print *, 'Input OK!'

        END

