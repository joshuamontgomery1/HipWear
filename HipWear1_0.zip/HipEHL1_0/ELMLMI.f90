SUBROUTINE ELMIML(HS,PS,ML,NXS,NYS)
       use H_coef
       use parameters
        real :: PS(0:NA,0:NB)
        real :: HS(0:NA,0:NB)
        integer :: ML
        integer :: NXS
        integer :: NYS
        integer :: LA, LA1
        integer :: I, J
        integer :: I2, J2
        integer :: IM1, IP1, IM3, IP3
        integer :: JM1, JP1, JM3, JP3
        integer :: K, L
        integer :: MX, MY
        integer :: NTA, NTB
        integer :: NAD, NBD
        integer :: M2 = 0

        DO  LA=KD,ML
        DO  I=-NL,NA+NL
        DO  J=-NL,NB+NL
        PL(LA,I,J)=0.0
        END DO
        END DO
        END DO
        DO  I=0,NXS
        DO  J=0,NYS
        PL(ML,I,J)=PS(I,J)
        END DO
        END DO

        NTA=NXS
        NTB=NYS
        DO 80 LA=ML-1,KD,-1
        LA1=LA+1
        NTA=NTA/2
        NTB=NTB/2
        DO 70 I=-2,NTA+2
        I2=I*2
        IM1=I2-1
        IP1=I2+1
        IM3=I2-3
        IP3=I2+3
        DO 60 J=-2,NTB+2
        J2=J*2
        JM1=(J2-1)
        JP1=J2+1
        JM3=(J2-3)
        JP3=J2+3
        PL(LA,I,J)=PL(LA1,I2,J2)     &
        +9.0*(PL(LA1,IM1,J2)+PL(LA1,I2,JM1)+PL(LA1,I2,JP1)+PL(LA1,IP1,J2))/16.0      &
        +81.0*(PL(LA1,IM1,JM1)+PL(LA1,IM1,JP1)+PL(LA1,IP1,JM1)     &
        +PL(LA1,IP1,JP1))/256.0     &
        +1.0*(PL(LA1,IM3,JM3)+PL(LA1,IM3,JP3)+PL(LA1,IP3,JM3)+PL(LA1,IP3,JP3))/256.0 &
        -9.0*(PL(LA1,IM3,JM1)+PL(LA1,IM3,JP1)+PL(LA1,IM1,JM3)     &
          +PL(LA1,IM1,JP3)+PL(LA1,IP1,JM3)+PL(LA1,IP1,JP3)     &
          +PL(LA1,IP3,JM1)+PL(LA1,IP3,JP1))/256.0     &
        -1.0*(PL(LA1,IM3,J2)+PL(LA1,I2,JM3)+PL(LA1,I2,JP3)     &
          +PL(LA1,IP3,J2))/16.0
   60   CONTINUE
   70   CONTINUE
   80   CONTINUE

        NAD=NTA+2
        NBD=NTB+2
        DO 120 I=-2,NAD
        DO 110 J=-2,NBD
        EDD(I,J)=0.0
        DO 100 K=-2,NAD
        MX=IABS(I-K)
        EDD(I,J)=EDD(I,J)+DBS(MX,J+2)*PL(KD,K,-2)
        DO 90 L=-1,NBD
        MY=IABS(J-L)
        EDD(I,J)=EDD(I,J)+DBS(MX,MY)*PL(KD,K,L)
   90   CONTINUE
  100   CONTINUE
  110   CONTINUE
  120   CONTINUE

        DO 270 LA=KD+1,ML
        NTA=NXS/2**(ML-LA)+4
        NTB=NYS/2**(ML-LA)+4
        DO 160 I=-4,NTA,2
        DO 150 J=-4,NTB,2
        ED(I,J)=EDD(I/2,J/2)
        DO 140 K=-MDA(LA)+I,MDA(LA)+I
        MX=IABS(I-K)
        DO 130 L=-MDB(LA)+J,MDB(LA)+J
        MY=IABS(J-L)
        ED(I,J)=ED(I,J)+CS1(LA,MX,MY)*PL(LA,K,L)
  130   CONTINUE
  140   CONTINUE
  150   CONTINUE
  160   CONTINUE

        DO 200 J=-4,NTB-3,2
        DO 190 I=-1,NTA-3,2
        ED(I,J)=9.0*(ED(I-1,J)+ED(I+1,J))/16.0     &
         -1.0*(ED(I-3,J)+ED(I+3,J))/16.0
        DO 180 K=-MDA(LA)+I,MDA(LA)+I
        MX=IABS(I-K)
        DO 170 L=-M2+J,M2+J
        MY=IABS(J-L)
        ED(I,J)=ED(I,J)+CS2(LA,MX,MY)*PL(LA,K,L)
  170   CONTINUE
  180   CONTINUE
  190   CONTINUE
  200   CONTINUE

        DO 240 J=-1,NTB-3,2
        JM1=(J-1)
        JP1=J+1
        JM3=(J-3)
        JP3=J+3
        DO 230 I=-2,NTA-2
        ED(I,J)=9.0*(ED(I,JM1)+ED(I,JP1))/16.0     &
         -1.0*(ED(I,JM3)+ED(I,JP3))/16.0
        DO 220 K=-M2+I,M2+I
        MX=IABS(I-K)
        DO 210 L=-MDB(LA)+J,MDB(LA)+J
        MY=IABS(J-L)
        ED(I,J)=ED(I,J)+CS3(LA,MX,MY)*PL(LA,K,L)
  210   CONTINUE
  220   CONTINUE
  230   CONTINUE
  240   CONTINUE

        DO 260 I=-4,NTA
        DO 250 J=0,NTB
        EDD(I,J)=ED(I,J)
  250   CONTINUE
  260   CONTINUE
  270   CONTINUE
        DO 290 I=0,NXS
        DO 280 J=0,NYS
        HS(I,J)=EDD(I,J)
  280   CONTINUE
  290   CONTINUE
        END
