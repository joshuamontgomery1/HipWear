# -*- mode: python ; coding: utf-8 -*-

# ------------------------------------------------------------
# Minimal PySide6 imports (avoid QtWebEngine crash)
# ------------------------------------------------------------
hiddenimports_qt = [
    'PySide6.QtWidgets',
    'PySide6.QtGui',
    'PySide6.QtCore',
]

datas_qt = []
binaries_qt = []

# ------------------------------------------------------------
# Main analysis block
# ------------------------------------------------------------
a = Analysis(
    ['GUI7.py'],
    pathex=[],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    noarchive=False,
    optimize=0,
    datas=datas_qt,
    binaries=binaries_qt,
    hiddenimports=hiddenimports_qt,
)
print("=== DEBUG: a.binaries ===")
for item in a.binaries:
    print(item)

print("=== DEBUG: a.datas ===")
for item in a.datas:
    print(item)

print("=== DEBUG: a.zipfiles ===")
for item in a.zipfiles:
    print(item)

print("=== DEBUG: a.scripts ===")
for item in a.scripts:
    print(item)

# ------------------------------------------------------------
# Add HipEHL manually (correct 3‑tuple)
# ------------------------------------------------------------
a.binaries += [
    ('HipEHL.cp314-win_amd64.pyd',
     r'C:\Users\Lenovo\OneDrive - University of Essex\Fortran\Scoping\Scoping013 - Outputs\HipEHL.cp314-win_amd64.pyd',
     'BINARY')
]

# ------------------------------------------------------------
# Add your data files
# ------------------------------------------------------------
a.datas += [
    ('2nd cycle/wc_a.dat', '2nd cycle'),
    ('2nd cycle/wv.dat', '2nd cycle'),
    ('2nd cycle/wv_cp.dat', '2nd cycle'),
    ('2nd cycle/hmcpmax.dat', '2nd cycle'),
    ('2nd cycle/p_entr.dat', '2nd cycle'),
    ('2nd cycle/p_side.dat', '2nd cycle'),
]

# ------------------------------------------------------------
# Build executable
# ------------------------------------------------------------
pyz = PYZ(a.pure)

exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.zipfiles,
    a.datas,
    name='HipEHL_GUI',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    console=False,
)

# ------------------------------------------------------------
# Collect everything into final dist folder
# ------------------------------------------------------------
coll = COLLECT(
    exe,
    a.binaries,
    a.zipfiles,
    a.datas,
    strip=False,
    upx=True,
    name='HipEHL_GUI',
)
