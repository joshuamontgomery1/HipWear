function plot1
n=129;
p=importdata('p.dat'); %the 51st time step where load is maximum
h=importdata('wc_a.dat');
t=linspace(0,180,n);
f=t;
[ff,tt]=meshgrid(f,t);
% fig_ph_3D(p,h,ff,tt)
% fig_ph_contour(p,h,f,t)
nt=1:10:40;
%fig_ph_section(nt)
 fig_pmax
end

function fig_ph_3D(p,h,ff,tt)
figure
subplot(2,1,1)
surf(ff,tt,p)
subplot(2,1,2)
surf(ff,tt,h)
end

function fig_ph_contour(p,h,f,t)
figure
 v=[0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 1 ];
 v1=v*6;
 v2=v*1e-4;
 subplot(2,1,1)
[C,s]=contour(f,t,p,v1); 
clabel(C,s,v1,'LabelSpacing',75);
axis([0,180,0,180])
subplot(2,1,2)
[C,s]=contour(f,t,h,v2); 
clabel(C,s,v2,'LabelSpacing',75);
axis([0,180,0,180])
end

function fig_ph_section(nt)
%%cross-section 2D plot at certain time steps 
p=importdata('p_entr.dat');
h=importdata('h_entr.dat');
figure
subplot(2,1,1)
plot(p(:,1),p(:,nt+2))
subplot(2,1,2)
plot(h(:,1),h(:,nt+2))
axis([0,180,0,10])
xlabel('\theta (deg)','fontsize',12')
end

function fig_pmax
p=importdata('hmcpmax.dat');
figure 
plot(p(:,1),p(:,5),'linewidth',2)
xlabel('Time (s)','fontsize',12)
ylabel('Maximum Pressure (MPa)')
end

