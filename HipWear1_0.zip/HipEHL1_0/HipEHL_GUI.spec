# -*- mode: python ; coding: utf-8 -*-

block_cipher = None

a = Analysis(
    ['GUI7.py'],
    pathex=['.'],
    binaries=[],
    datas=[
        ('2nd cycle/wc_a.dat', '2nd cycle'),
        ('2nd cycle/wv.dat', '2nd cycle'),
        ('2nd cycle/wv_cp.dat', '2nd cycle'),
        ('2nd cycle/hmcpmax.dat', '2nd cycle'),
        ('2nd cycle/p_entr.dat', '2nd cycle'),
        ('2nd cycle/p_side.dat', '2nd cycle'),
    ],
    hiddenimports=[
        'PySide6.QtWidgets',
        'PySide6.QtGui',
        'PySide6.QtCore',
    ],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    noarchive=False,
)

# Manually add HipEHL binary
a.binaries += [
    (
        'HipEHL.cp311-win_amd64.pyd',
        r'C:\Users\Lenovo\OneDrive - University of Essex\Fortran\Scoping\Scoping013 - Outputs\HipEHL.cp311-win_amd64.pyd',
        'EXTENSION'
    )
]

pyz = PYZ(a.pure, a.zipped_data, cipher=block_cipher)

exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.zipfiles,
    a.datas,
    name='HipEHL_GUI',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    console=False,
)

coll = COLLECT(
    exe,
    a.binaries,
    a.zipfiles,
    a.datas,
    strip=False,
    upx=True,
    name='HipEHL_GUI',
)
