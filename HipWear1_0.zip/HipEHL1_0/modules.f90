
        module parameters
        implicit none
        integer, parameter :: M = 3
        integer, parameter :: NA = 128
        integer, parameter :: NB = NA
        integer :: n_gts
        integer, parameter :: KD = 1
        integer, parameter :: N25 = 25

        integer, parameter :: NL = 30
        integer, parameter :: NMA = NA + 4*2**(M-KD)
        integer, parameter :: NMB = NMA
        real, parameter :: PI = 3.1415926
        real :: CR12
        real :: R0
        real :: E0
        real, parameter :: Ra = 2.0E-6
        real, parameter :: fcp = 3E-4
        real, parameter :: th = 6E-3

        end module parameters

       Module H_coef
       Use parameters
       implicit none
        real :: C1(KD:M,KD:M,0:NL,0:NL)
        real :: C2(KD:M,KD:M,0:NL,0:NL)
        real :: C3(KD:M,KD:M,0:NL,0:NL)
        real :: CS1(KD:M,0:NL,0:NL)
        real :: CS2(KD:M,0:NL,0:NL)
        real :: CS3(KD:M,0:NL,0:NL)
        real :: ED(-4:NA+4,-4:NB+4)
        real :: EDD(-4:NA+4,-4:NB+4)
        integer :: MDA(M)
        integer :: MDB(M)
        real :: PL(M,-NL:NA+NL,-NL:NB+NL)
        real :: DB(M,0:NMA,0:NMB)
        real :: DB0(M,0:NMA,0:NMB)
        real :: DBS(0:NMA,0:NMB)
        real :: DHDP(M,2)

       End module H_coef

       Module sin_define
        use parameters
        implicit none
        real :: SINX(M,0:NA)
        real :: COSX(M,0:NA)
        real :: SINY(M,0:NB)
        real :: COSY(M,0:NB)
        real :: SINYM(M,NB-1)
        real :: SINYP(M,NB-1)
       !common    sinx,cosx,siny,cosy,sinym,sinyp
       End module sin_define

       Module loading
        use parameters
        implicit none
        real,allocatable :: WXT(:)
        real,allocatable  :: WYT(:)
        real,allocatable  :: WZT(:)
        real,allocatable  :: t(:)
        real,allocatable  :: OXT(:)
        real,allocatable  :: OYT(:)
        real,allocatable  :: OZT(:)
       ! contains


      ! Subroutine rotation (v_rot3,theta,phi,nt)
      !
      !  integer, parameter :: n=3
      !  real :: theta,phi
      !  real :: vx(n)=(/1.,0.,0./),vy(n)=(/0.,1.,0./),vz(n)=(/0.,0.,1./)
      !  real :: v(n),v_rot1(n),v_rot2(n),v_rot3(n)
      !
      !  open(15,file='trac.dat')
      !
      !  theta=0.5*pi
      !  phi=0.5*pi
      !   nt=100
      !  v(1)=sin(theta)*cos(phi)
      !  v(2)=sin(theta)*sin(phi)
      !  v(3)=cos(theta)
      !
      !  do it=1,nt
      !      call Rodrig(ay(it),vy,v,n,v_rot1)
      !      call Rodrig(ax(it),vx,v_rot1,n,v_rot2)
      !      call Rodrig(az(it),vz,v_rot2,n,v_rot3)
      !      write(15,*) v_rot3
      !  end do
      !  return
      !  end subroutine
      !
      !Subroutine Rodrig(beta,k,v,n,v_rot) !beta (rad)
      !  integer :: n
      !  real :: beta,k(n),v(n),v_rot(n),cr(n)
      !  call cross(k,v,cr,n)
      !  v_rot=v*cos(beta)+cr*sin(beta)+k*dot_product(k,v)*(1-cos(beta))
      !  end subroutine
      !
      !Subroutine cross(a, b, cr, n)
      !  implicit none
      !  integer :: n
      !  real :: a(n),b(n),cr(n)
      !    cr(1) = a(2) * b(3) - a(3) * b(2)
      !    cr(2) = a(3) * b(1) - a(1) * b(3)
      !    cr(3) = a(1) * b(2) - a(2) * b(1)
      !  end subroutine
       End Module loading



