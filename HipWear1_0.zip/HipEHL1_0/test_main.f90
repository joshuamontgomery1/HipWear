program test_main
use wear_wrapper
use parameters

implicit none
integer :: nt1=1
integer :: nt2=1
real :: pmax1
real :: pmax_array(0:NA)
real :: hmin
!real :: input_load=300.0
!real :: input_speed=-2.0
real :: omigp_in=0.2
real :: omiex_in=1.0
real :: omiey_in=1.0
real :: omiez_in=1.0
real :: facx_in=20.0
real :: facy_in=20.0
real :: facz_in=30.0
real :: errc_in=0.05
real :: errp_con_in=0.01
real :: erwx_con_in=0.05
real :: erwy_con_in=0.01
real :: erwz_con_in=0.05
integer :: n_w_circle_in=100
real :: alpha_in=1e-16
integer :: n_updt_intv_in=1e6
integer :: n_updt=1
integer :: icase_in=2
real :: cr12_in = 50E-6
real :: r0_in = 0.016
real :: e0_in = 660E6
integer :: n_gts_in =50

call wear_run(nt1,nt2,pmax1, hmin,pmax_array,&
                        omigp_in, omiex_in, omiey_in, omiez_in, facx_in, facy_in, facz_in, errp_con_in, &
                        erwx_con_in, erwy_con_in, erwz_con_in, errc_in, n_w_circle_in,cr12_in,r0_in,e0_in, &
                        alpha_in,n_updt_intv_in,n_updt,icase_in,n_gts_in )
print *, pmax1, hmin

end program test_main
